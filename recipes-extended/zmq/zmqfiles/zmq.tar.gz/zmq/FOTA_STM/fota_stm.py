"""
 FileName      : fota_stm.py

 Description   : This file contains the implementation of FOTA_STM ZMQ dealer. which is reponsible to handle
                 all the incoming message from the Router application. Also sent response to that perticular message
                 with data. Main task of this application is to install the newly received OTA package in to the device 

 Author        : Noccarc
"""
import threading
import zmq
import subprocess 
import json
from json.decoder import JSONDecodeError
import logging
import logging.handlers
import traceback
import sys
from app_macros import *
import time
import socket
import hashlib
import os
import zipfile
import shutil
from distutils.dir_util import copy_tree
import stat

class fota_stm():
    """
    Class        : fota_stm
    Inherits     :
    Description  : Main application class which is handling the ZMQ messages 
    """
    def __init__(self):
        """
        Function: __init__
        Description: init method of class
        @param:
        @return:
        """
        threading.Thread.__init__(self)
        self.name = "FOTA_STM"
        # Intialize the ZMQ dealer instance for the FOTA_STM 
        self.context = zmq.Context.instance()
        self.socket = self.context.socket(zmq.DEALER)
        self.socket.setsockopt(zmq.IDENTITY, bytes(FOTA_STM_DEALER_ID_STR, 'utf-8'))
        # Make connect call with the Router 
        self.socket.connect(ROUTER_SOCKET_ADDRESS)
        logging.debug("ZMQ connect request sent, dealerID: {0} socketID: {1}".format(FOTA_STM_DEALER_ID, zmq.IDENTITY))

    def send_data(self, dJSONMsg):
        """
        Function: send_data
        Description: Send the JSON message to router application
        @param dJSONMsg: JSON dictonary to be sent to Router application
        @return: 
        """
        try:
            logger.info(">>>  {}".format(dJSONMsg))

            #Convert JSON message dictonary to string
            json_obj_to_send = json.dumps(dJSONMsg)
            self.socket.send_multipart([b'1', bytes(json_obj_to_send,'utf-8')])
            logger.debug("JSON message sent to the Router")
        except Exception as e:
            logger.error("Failed to send JSON message: {0} error: {1}".format(dJSONMsg,e))
            logger.error(traceback.format_exc())

    def keys_exists(self, dJSONMsg, *strKeys):
        """
        Function: send_data
        Description: Check if *strKeys (nested) exists in input dJSONMsg (dict).
        @param dJSONMsg: JSON dictonary
        @param strKeys: JSON Keys
        @return: True if key exists otherwise false
        """
        try:
            if not isinstance(dJSONMsg, dict):
                logger.error('keys_exists() expects dict as first argument.')
                return False
            if len(strKeys) == 0:
                logger.error('keys_exists() expects at least two arguments, one given.')
                return False

            _element = dJSONMsg
            for key in strKeys:
                try:
                    _element = _element[key]
                except KeyError:
                    return False
        except Exception as e:
            logger.error("Failed to check key exists in dictonary: {0} error: {1}".format(dJSONMsg,e))
            logger.error(traceback.format_exc())
            return False

        return True

    def getMD5SUMofFile(self, strFileName):
        strMD5SUM = None
        try:
            with open(strFileName, 'rb') as file_to_check:
                # TODO: Need to think file read logic in case of file is big
                # read contents of the file
                data = file_to_check.read()    
                # pipe contents of the file through
                strMD5SUM = str(hashlib.md5(data).hexdigest())
        except Exception as e:
            logger.error("Failed to calculate the MD5SUM of file: {0} error: {1}".format(strFileName,e))
            logger.error(traceback.format_exc())
        return strMD5SUM

    def download_and_verify_package(self, dJSONMsg):
        bReturnStatus = False
        try:
            strSCPArgs = "root@" + IOMT_IP_ADDRESS + ":" + str(dJSONMsg[DATA_KEY][PKG_LOCATION_KEY])
            logger.info("SCP command argument is: {0}".format(strSCPArgs))
            subprocess.run(["scp",strSCPArgs,"."])
            strPkgName = str(dJSONMsg[DATA_KEY][PKG_NAME_KEY])

            if(True == os.path.exists(strPkgName) and (True == zipfile.is_zipfile(strPkgName))):
                if(self.getMD5SUMofFile(strPkgName)):
                    logger.info("Received package MD5sum matched")
                    strOTADirPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), str(dJSONMsg[DATA_KEY][PKG_VERSION_KEY]))
                    logger.info("OTA package path is : {}".format(strOTADirPath))
                    # loading the temp.zip and creating a zip object
                    with zipfile.ZipFile(dJSONMsg[DATA_KEY][PKG_NAME_KEY], 'r') as zObject:
                        zObject.extractall(".")
                    
                    for key in ota_pkg_files_locaiton:
                        if(True != os.path.exists(os.path.join(strOTADirPath,ota_pkg_files_locaiton[key]))):
                            logger.error("{0} is not available in OTA package".format(key))
                            bReturnStatus = False
                            break
                        else:
                            bReturnStatus = True
                else:
                    logger.error("Calcuated and received MD5SUM mismatched of file: {0}".format(strPkgName))
            else:
                logger.error("Copied file not exists, Something went wrong")
        except Exception as e:
            logger.error("Failed to check key exists in dictonary: {0} error: {1}".format(dJSONMsg,e))
            logger.error(traceback.format_exc())

        return bReturnStatus
    
    def install_package(self, dJSONMsg):
        bReturnValue = False

        try:
            strSourcePath = ""
            strDestinationPath = ""
            strOTADirPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), str(dJSONMsg[DATA_KEY][PKG_VERSION_KEY]))

            strSourcePath = os.path.join(strOTADirPath, ota_pkg_files_locaiton["Master"])
            strDestinationPath = FIRMWARE_PATH_IN_DEVICE
            shutil.copy(strSourcePath, strDestinationPath)

            strSourcePath = os.path.join(strOTADirPath, ota_pkg_files_locaiton["Slave"])
            strDestinationPath = FIRMWARE_PATH_IN_DEVICE
            shutil.copy(strSourcePath, strDestinationPath)
            
            strBackendBinpath = os.path.join(SOFTWARE_BACKEND_PATH_IN_DEVICE,BACKEND_BINARY_NAME)
            logger.info("Removing the backend file: {}".format(strBackendBinpath))
            if(os.path.exists(strBackendBinpath)):
                os.remove(strBackendBinpath)
            strSourcePath = os.path.join(strOTADirPath, ota_pkg_files_locaiton["backend"])
            strDestinationPath = SOFTWARE_BACKEND_PATH_IN_DEVICE
            shutil.copy(strSourcePath, strDestinationPath)

            if(os.path.exists(strBackendBinpath)):
                st = os.stat(strBackendBinpath)
                os.chmod(strBackendBinpath, st.st_mode | stat.S_IEXEC)

            # copy_tree API is copying the source directory files to destination directory, It is not creating 
            # the source directory at destination side, So here we first create the "Noccarc_UI" at destination
            # and copy the UI data into the created destination directory 
            strSourcePath = os.path.join(strOTADirPath, ota_pkg_files_locaiton["UI"])
            strDestinationPath = SOFTWARE_UI_PATH_IN_DEVICE + ota_pkg_files_locaiton["UI"].split("/")[1]
            if(not (os.path.exists(strDestinationPath))):
                os.makedirs(strDestinationPath)
            copy_tree(strSourcePath, strDestinationPath)

            # start the firmware flashing
            if True == self.flash_firmware():
                logger.info("Firware flashed successfully ....!")
                bReturnValue = True
            else:
                logger.info("Firware flashing failed!!!!")

            logger.info("Removing the OTA package related files")
            if(os.path.exists(strOTADirPath)):
                shutil.rmtree(strOTADirPath)

            if(os.path.exists(dJSONMsg[DATA_KEY][PKG_NAME_KEY])):
                os.remove(dJSONMsg[DATA_KEY][PKG_NAME_KEY])

        except Exception as e:
            logger.error("Failed to check key exists in dictonary: {0} error: {1}".format(dJSONMsg,e))
            logger.error(traceback.format_exc())

        return bReturnValue        

    def flash_firmware(self):
        iRetry_count = 3
        bIsErrorFound = False

        while(iRetry_count > 0):
            logger.info("Firmware Flashing started ...!")
            try:
                stdout = subprocess.check_output(
                    "/usr/local/VCB-OTA/OTA/xpack-openocd-0.11.0-2/bin/openocd -d2 -l firmware_flash_logs.txt  \
                    -f /usr/local/VCB-OTA/OTA/xpack-openocd-0.11.0-2/scripts/interface/ftdi/dp_busblaster_kt-link.cfg \
                    -f /usr/local/VCB-OTA/OTA/xpack-openocd-0.11.0-2/scripts/board/stm32nocca.cfg \
                    -f /usr/local/VCB-OTA/OTA/xpack-openocd-0.11.0-2/scripts/board/VCB_flash.cfg", shell=True)

            except subprocess.CalledProcessError as e:
                logger.error("Firmware flashing failed error: {}".format(e))
                logger.error(traceback.format_exc())

            # Opening the log file to check firmware flashing error occur or not
            with open("firmware_flash_logs.txt", encoding='utf-8') as f:
                output = f.read().split('\n')

            error_list = []

            for each_line in output:
                if(each_line.startswith("Error:")):
                    error_list.append(each_line)
            
            for key in dFlashErrorList:
                if(dFlashErrorList[key] in error_list):
                    logger.info("ERROR found during flashing: {}".format(dFlashErrorList[key]))
                    bIsErrorFound = True
            
            if(bIsErrorFound):
                logger.info("Reflashing the firmware, Retry count: {}".format(iRetry_count))    
                iRetry_count = iRetry_count - 1
                bIsErrorFound = False
                # TODO : Is it require to delete the firmware flash log file ? If yes uncomment below line
                #os.remove("firmware_flash_logs.txt")
                time.sleep(DELAY_BETWEEN_TWO_FIRMWARE_FLASH)
            else:
                break

        if(iRetry_count == 0):
            return False
        else:
            return True

    def sendInValidJSONMessage(self, dJSONMsg, iDestinationDealerId, iMessageType):
        iMsgType = 0
        if(iMessageType == MSG_TYPE_PKG_DOWNLOADED):
            if self.keys_exists(dJSONMsg,DATA_KEY,PKG_TYPE_KEY):
                if dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_UPGRADE:
                    iMsgType = MSG_TYPE_PKG_UPGRADE
                elif dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_ROLLBACK:
                    iMsgType = MSG_TYPE_PKG_ROLLBACK
            else:
                iMsgType = MSG_TYPE_PKG_DOWNLOADED
        else:
            iMsgType = iMessageType

        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
        dJSONMsg[DESTINATION_KEY] = iDestinationDealerId
        dJSONMsg[MESSAGE_TYPE_KEY] = iMsgType
        dJSONMsg[STATUS_KEY] = ERROR_CODE_INVALID_JSON
        dJSONMsg[DATA_KEY] = {}
        self.send_data(dJSONMsg)
    
    def run(self):
        """
        main thread
        @return:
        """

        dJSONMsg = {}
        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
        dJSONMsg[DESTINATION_KEY] = ROUTER_ID
        dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_REG
        dJSONMsg[DATA_KEY] = {}

        self.send_data(dJSONMsg)
        
        # infinite while loop which is responsible to handle the all the ZMQ messages
        while True:
            logger.debug("Entering in to the infinite loop")

            # Blocking zmq received call 
            self.socket.recv()
            received_data = self.socket.recv()

            logger.info("<<< {0}".format(received_data))
            dJSONMsg.clear()
            # convery received JSON message string in to the dictonary, So that we can 
            # easily read all the parameters of JSNO message
            try:
                dJSONMsg = json.loads(received_data)
            except JSONDecodeError as e:
                logger.error("JSON parsing failed: {0}".format(e))
                logger.error(traceback.format_exc())

            if self.keys_exists(dJSONMsg, MESSAGE_TYPE_KEY):
                if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_HEART_BEAT:
                    dJSONMsg.clear()
                    dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                    dJSONMsg[DESTINATION_KEY] = ROUTER_ID
                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_HEART_BEAT
                    dJSONMsg[STATUS_KEY] = SUCCESS
                    dJSONMsg[DATA_KEY] = {}
                    self.send_data(dJSONMsg)
                elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_UPGRADE or \
                        dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_ROLLBACK:
                    if self.keys_exists(dJSONMsg,DATA_KEY,PKG_VERSION_KEY):
                        strPkgVersion = str(dJSONMsg[DATA_KEY][PKG_VERSION_KEY])
                        iMsgType = dJSONMsg[MESSAGE_TYPE_KEY]
                        dJSONMsg.clear()
                        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                        dJSONMsg[DESTINATION_KEY] = FOTA_IOMT_DEALER_ID
                        dJSONMsg[MESSAGE_TYPE_KEY] = iMsgType
                        dJSONMsg[DATA_KEY] = {PKG_VERSION_KEY:strPkgVersion}
                        self.send_data(dJSONMsg)
                    else:
                        logger.error("verison keys is not avaialble in received JSON message: {0}".format(dJSONMsg))
                        self.sendInValidJSONMessage(dJSONMsg,BACKEND_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])
                elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_DOWNLOADED:
                    if (self.keys_exists(dJSONMsg,STATUS_KEY)) and (dJSONMsg[STATUS_KEY] == SUCCESS):
                        if self.keys_exists(dJSONMsg,DATA_KEY,PKG_VERSION_KEY) and \
                            self.keys_exists(dJSONMsg,DATA_KEY,PKG_NAME_KEY) and \
                            self.keys_exists(dJSONMsg,DATA_KEY,PKG_SIZE_KEY) and \
                            self.keys_exists(dJSONMsg,DATA_KEY,PKG_MD5SUM_KEY) and \
                            self.keys_exists(dJSONMsg,DATA_KEY,PKG_LOCATION_KEY) and \
                            self.keys_exists(dJSONMsg,DATA_KEY,PKG_TYPE_KEY):

                            strPkgVersion = str(dJSONMsg[DATA_KEY][PKG_VERSION_KEY])
                            
                            # Decide package type from received message
                            if dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_UPGRADE:
                                iMsgType = MSG_TYPE_PKG_UPGRADE
                            elif dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_ROLLBACK:
                                iMsgType = MSG_TYPE_PKG_ROLLBACK

                            dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                            dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                            dJSONMsg[MESSAGE_TYPE_KEY] = iMsgType

                            if True == self.download_and_verify_package(dJSONMsg):
                                if(not (os.path.exists(SOFTWARE_BACKEND_PATH_IN_DEVICE))):
                                    os.makedirs(SOFTWARE_BACKEND_PATH_IN_DEVICE)
                                if(not (os.path.exists(SOFTWARE_UI_PATH_IN_DEVICE))):
                                    os.makedirs(SOFTWARE_BACKEND_PATH_IN_DEVICE)
                                if(not (os.path.exists(FIRMWARE_PATH_IN_DEVICE))):
                                    os.makedirs(FIRMWARE_PATH_IN_DEVICE)

                                if True == self.install_package(dJSONMsg):
                                    dJSONMsg[DATA_KEY] = {PKG_VERSION_KEY:strPkgVersion}
                                    dJSONMsg[STATUS_KEY] = SUCCESS
    
                                else:
                                    dJSONMsg[STATUS_KEY] = ERROR_CODE_FAILED_TO_INSTALL_PKG
                                    dJSONMsg[DATA_KEY] = {}
                            else:
                                logger.error("Received package verification failed")
                                dJSONMsg[STATUS_KEY] = ERROR_CODE_PACKAGE_VERIFICATION_FAILED
                                dJSONMsg[DATA_KEY] = {}

                            self.send_data(dJSONMsg)
                            # Also send the rollback status message to FOTA_IOMT application, So that
                            # it can delete the latest package
                            if(iMsgType == MSG_TYPE_PKG_ROLLBACK):
                                dJSONMsg[DESTINATION_KEY] = FOTA_IOMT_DEALER_ID
                                dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_ROLLBACK_FEEDBACK
                                self.send_data(dJSONMsg)
                        else:
                            logger.error("InSuffiecient keys in received JSON message: {0}".format(dJSONMsg))
                            self.sendInValidJSONMessage(dJSONMsg,BACKEND_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])
                    else:
                        # carry forwarding the status to backend application, as status is not SUCCESS
                        if self.keys_exists(dJSONMsg,STATUS_KEY) and \
                            self.keys_exists(dJSONMsg,DATA_KEY,PKG_TYPE_KEY):
                            
                            # Decide package type from received message
                            if dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_UPGRADE:
                                iMsgType = MSG_TYPE_PKG_UPGRADE
                            elif dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_ROLLBACK:
                                iMsgType = MSG_TYPE_PKG_ROLLBACK

                            dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                            dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                            dJSONMsg[MESSAGE_TYPE_KEY] = iMsgType
                            dJSONMsg[DATA_KEY] = {}
                            self.send_data(dJSONMsg)
                        else:
                            logger.error("InValid keys in received JSON message: {0}".format(dJSONMsg))
                            self.sendInValidJSONMessage(dJSONMsg,BACKEND_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])
            else:
                logger.error("Message type key is not found in: {0}".format(dJSONMsg))
                # Sending the Invalid JSON message, because we didn't get message type
                # cosidering the message type 0
                self.sendInValidJSONMessage(dJSONMsg,BACKEND_DEALER_ID,0)

                            
""" 
Function: logging_setup
Description: This function setup the logging for the Application. This function takes the 
values from the logging_types dictonary. based on that it will decide where applicaiton logs 
should be print on colsole and logging file
"""
def logging_setup():
    root = logging.getLogger()
    root.setLevel(logging.INFO)

    # Print the logs in to the console, if "log_into_console" key is true
    if logging_types['log_into_console'] == True:
        ch = logging.StreamHandler(sys.stdout)
        # TODO: Here developer can decide the log level which will be print over the console
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        root.addHandler(ch)

    # Store the logs in to the file if "log_into_file" key is true
    if logging_types['log_into_file'] == True:
        log_file_handler = logging.handlers.RotatingFileHandler(LOG_FILE_NAME, maxBytes = LOG_FILE_SIZE, backupCount = LOG_FILE_BACK_COUNT)
        # TODO: Here developer can decide the log level which will stored in to the log file
        log_file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        log_file_handler.setFormatter(formatter)
        root.addHandler(log_file_handler)
    return root

# Logging setup
logger = logging_setup()

mian_obj = fota_stm()
mian_obj.run()