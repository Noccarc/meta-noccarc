from email import message
import socket
import threading
import os
import tarfile
from time import sleep
from urllib import response
from zipfile import ZipFile
import time
import filetype

host = "10.1.0.191"
port = 12345
final_extract_location = os.path.dirname(os.path.realpath(__file__))
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print("waiting for connection...")
with clientSocket as c:
    c.connect((host,port))
    information_send_status=False
    connection_status=False
    def sendInformation():
        version_number = input('Enter Version Number: ')
        update_type=input('Enter Update type: ')
        updat_mode=input('Enter update mode(i.e:rollback=0,new=1) : ')
        message=version_number + ":" + update_type + ":" + updat_mode 
        print(message)
        c.send(message.encode('utf-8'))
    def sendFeedback(msg):
       c.send(bytes((msg),encoding= 'utf-8'))

    def extractfile(file_name):
        #file_name="/home/samar/Documents/crank/settingdropdown.zip"
        kind = filetype.guess(file_name)
        print(kind.extension,kind)
        try:
            #filename='/home/samar/Documents/V730i.zip'
            with ZipFile(file_name, 'r') as zip:
                # printing all the contents of the zip file
                zip.printdir()
                        # extracting all the files
                #print('Extracting all the files now...')
                zip.extractall(final_extract_location)
                print('Done!')
        except Exception as e:
            print("Error:", e)

    def downloadfile(file_name,filesize):
        filesize = int(filesize)
        cycles=filesize/1024
        percent=0
        #print(progress,filename,filesize)
        with open(file_name, "wb") as f:
            while True:
                # read 1024 bytes from the socket (receive)
                if(int(percent) >=100):
                    f.close()
                    print("file copied")
                    break
                bytes_read = c.recv(1024)

                # write to the file the bytes we just received
                f.write(bytes_read)
                percent+= (100/cycles)
                #print(int(percent))
        if(int(percent) >= 100):
            print("filed copied successfully")
            kind = filetype.guess(file_name)
            file_exists = os.path.exists(file_name)
            print(os.path.getsize(file_name))
            close=f.closed
            print(file_name,kind,file_exists,close,kind.extension)
            time.sleep(2)
            extractfile(file_name)
            return kind.extension

    while True:
        if(not information_send_status):
            sendInformation()
            print("waiting for response from server...")
            res=c.recv(1024).decode('utf-8')
            if(res=='t'):
                print("resp",res)
                sendFeedback("t")
                print("waiting for file information...")
                file_info_recv=c.recv(1024).decode('utf-8')
                print("file_infor",file_info_recv)
                if(len(file_info_recv)>1):
                    filename, filesize=file_info_recv.split(":") 
                    dir_path = os.path.dirname(os.path.realpath(__file__))
                    print("current path:",dir_path)
                    file_name=os.path.join(dir_path,os.path.basename(filename))
                    sendFeedback("t")
                    file_type=downloadfile(file_name,filesize)
                    if(file_type=="zip"):
                        sendFeedback("t") 
                else:
                    if(file_info_recv=='f'):
                        sendInformation()
                    elif(file_info_recv=="a"):
                        print("New Version is available")
                    elif(file_info_recv=="b"):
                        print("System is upto-dated")
                    elif(file_info_recv=="n"):
                        print("old version is not available")


            
            
            
                
            


            

    






# with clientSocket as c:
#     c.connect((host, port))
#     response = c.recv(2048)
#     def sending():
#             version_number = input('Enter Version Number: ')
#             update_type=input('Enter Update type: ')
#             updat_mode=input('Enter update mode(i.e:rollback=0,new=1) : ')
#             message=version_number + ":" + update_type + ":" + updat_mode 
#             print(message)
#             c.send(message.encode('utf-8'))

