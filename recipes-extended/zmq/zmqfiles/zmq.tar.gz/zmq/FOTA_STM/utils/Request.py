
class Request:
    
    def __init__(self):
        """
        Function: __init__
        Description: init method of class
        @param:
        @return:
        """
        
        self.url=None
        self.ok = True
        self.message = ''
        self.data=None
    
    def urlMatch(self, arg):
        try:
            if (arg == None) or (not isinstance(arg, str)):
                return False
            
            arg = arg.strip()
            
            if(len(arg) <= 0):
                return False
            
            index = self.url.find(arg)
            if(index == -1):
                return False
            
            urlLastIndex = index + len(arg) - 1
            if(urlLastIndex+1 <= len(self.url)):
                return True
            elif(self.url[urlLastIndex+1] == '/'):
                return True
            else:
                return False
        
        except:
            return False
        
        
# req = Request()
# req.url = "a/bcde/fghijk"

# print("L1", req.urlMatch(Request()))
# print("L2", req.urlMatch(""))
# print("L3", req.urlMatch("      "))
# print("L4", req.urlMatch("ab"))
# print("L5", req.urlMatch("/////"))
# print("L6", req.urlMatch("a/bc"))
# print("L7", req.urlMatch("a/bcde"))
# print("L8", req.urlMatch("a/bcde/"))
# print("L9", req.urlMatch("a/bcde/fghijk"))
# print("L10", req.urlMatch("a/bcde/fghijk/"))
