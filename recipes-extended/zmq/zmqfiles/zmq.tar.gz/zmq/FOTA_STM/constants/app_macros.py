FOTA_IOMT_DEALER_ID = 4
FOTA_STM_DEALER_ID = 3
FOTA_STM_DEALER_ID_STR = '3'
BACKEND_DEALER_ID = 2
ROUTER_ID = 1
SOURCE_KEY='source'
DESTINATION_KEY='destination'
MESSAGE_TYPE_KEY='type'
DATA_KEY='data'
STATUS_KEY = 'status'
PKG_TYPE_KEY = 'pkg_type'
PKG_VERSION_KEY = 'version'

PKG_NAME_KEY = "name"
PKG_SIZE_KEY = "size"
PKG_MD5SUM_KEY = "md5sum"
PKG_LOCATION_KEY = "location"
# STATUS_KEY = "status"

#---- new----
PKG_SW_VERSION_KEY = "softwareVersion"
PKG_OS_VERSION_KEY = "osVersion"
PKG_UPDATEPKG_KEY ="update_pkg"
PKG_UPDATE_TYPE_KEY= "update_type"


# ------ 
TASK_ERR = 'task_error'


FIRMWARE_INTERNAL_ERROR = 7000
ERROR_JTAG_CONNECTION = 7001
ERROR_NO_DEVICE_FOUND =7002
ERROR_FTDI_DEVICE = 7003
ERROR_FIRMWARE_FILES_CORRUPTED = 7004
ERROR_TIMEOUT_FAILURE = 7005
FIRMWARE_VERIFICATION_ERROR = 7006

SOFTWARE_INTERNAL_ERROR = 7100
ERROR_INSTALLING_STMOS = 7200

MSG_TYPE_PKG_UPGRADE_FEEDBACK_ERROR = 22 # new 
MSG_TYPE_ROLLBACK_FEEDBACK_ERROR = 23 #new

FIRMWARE_ERROR_MAPPING = {
        "no_device_found": ERROR_NO_DEVICE_FOUND,
        "unable_to_open_ftdi": ERROR_FTDI_DEVICE,
        "timeout_waiting_for_algorithm": ERROR_TIMEOUT_FAILURE,
        "JTAG_connection_failed": ERROR_JTAG_CONNECTION ,
        "firmware_files_corrupted": ERROR_FIRMWARE_FILES_CORRUPTED,
    }



ROUTER_SOCKET_ADDRESS = "tcp://localhost:5555"
IOMT_IP_ADDRESS = "192.168.0.2" # production 
FIRMWARE_PATH_IN_DEVICE = "/usr/local/VCB-OTA/OTA/Firmware"
SOFTWARE_BACKEND_PATH_IN_DEVICE = "/usr/local/HMIfiles/apps/Noccarc_Backend"
SOFTWARE_UI_PATH_IN_DEVICE = "/usr/local/HMIfiles/apps/"

BARCODE_SCANNER_MODULE_DETECTION_COMMAND="lsusb -t | grep usbhid"
BARCODE_SCANNER_MODULE_INPUT_PATH="lsusb -t | grep usbhid"
V730i_BARCODE_LENGTH=19
EVTEST_COMMAND = 'evtest'


# FIRMWARE_PATH_IN_DEVICE = "/home/sandip/Documents/FOTA_NEW/FOTA_STM/VCB-OTA/OTA/Firmware"
# SOFTWARE_BACKEND_PATH_IN_DEVICE = "/home/sandip/Documents/FOTA_NEW/FOTA_STM/backend/apps/"
# SOFTWARE_UI_PATH_IN_DEVICE = "/home/sandip/Documents/FOTA_NEW/FOTA_STM/Crank/"

ota_pkg_files_locaiton = {   
"Master" : "Firmware/Master.hex", 
"Slave" : "Firmware/Slave.hex", 
"backend" : "Software/backend.bin", 
"UI" : "Software/Noccarc_UI",
}

sw_pkg_files_location = {
"backend" : "Software/backend.bin", 
"UI" : "Software/Noccarc_UI"
}

fw_pkg_files_location = {
"Master" : "Firmware/Master.hex", 
"Slave" : "Firmware/Slave.hex", 
}

BACKEND_BINARY_NAME = "backend.bin"

# ota_pkg_files_locaiton = {   \
# "Master" : "Firmware/Master.hex", \
# "Slave" : "Firmware/Slave.hex", \
# "backend" : "Software/V730i_1.1.1.17.bin", \
# "UI" : "Software/Noccarc_UI_1.1.1.18"
# }

dFlashErrorList = { \
1 : "Error: error executing stm32x flash write algorithm",              # Received ERROR when flash write failed
2 : "Error: JTAG-DP STICKY ERROR",                                      # Received ERROR when JTAG cable is not connected
3 : "Error: checksum mismatch - attempting binary compare"              # Received ERROR when checksum mismatch
} 

MSG_TYPE_REG = 1
MSG_TYPE_HEART_BEAT = 2
MSG_TYPE_NEW_UPDATE_CHECK = 5
MSG_TYPE_PKG_UPGRADE = 6
MSG_TYPE_PKG_UPGRADE_OS = 50 # old name  -> MSG_TYPE_PKG_DOWNLOADED , new name -> MSG_TYPE_PKG_UPGRADE_OS
MSG_TYPE_PKG_ROLLBACK  = 8
MSG_TYPE_CONNECTED_WIFI_NAME = 13
MSG_TYPE_ROLLBACK_FEEDBACK = 15
MSG_TYPE_ENTER_MACHINE_REGISTRATION=16
MSG_TYPE_SCANNER_MODULE_USB_CONNECT_STATUS=17
MSG_TYPE_SCANNER_MODULE_SERIAL_NUMBER_STATUS=18

MSG_TYPE_PKG_UPGRADE_FEEDBACK=20

LOG_FILE_NAME = "fota_stm_logging.txt"
LOG_FILE_SIZE = 1024 * 1024 * 2
LOG_FILE_BACK_COUNT = 3
DELAY_BETWEEN_TWO_FIRMWARE_FLASH = 3

SUCCESS = 1
ERROR_CODE_ROLLBACK_PKG_NOT_AVAILABLE = -3
ERROR_CODE_PKG_DOWNLOAD_FAILED = -5
ERROR_CODE_FAILED_TO_GET_NEW_UPDATE = -4
ERROR_CODE_PKG_NO_UPDATE_AVAILABLE = -6
ERROR_CODE_INVALID_JSON = -7
ERROR_CODE_WIFI_CONNECTED_NO_INTERNET = -8
ERROR_CODE_FAILED_TO_FETCH_WIFI_LIST = -9
ERROR_CODE_WIFI_CONNECT_FAILED = -10
ERROR_CODE_WIFI_NOT_CONNECTED_TO_STATION = -11
ERROR_CODE_FAILED_TO_OFF_WIFI = -12
ERROR_CODE_NO_PACKAGE_AVAILABLE = -13
ERROR_CODE_FAILED_TO_INSTALL_PKG = -15
ERROR_CODE_PACKAGE_VERIFICATION_FAILED = -16
ERROR_CODE_INVALID_PACKAGE_INFO_JSON = -17
ERROR_CODE_MACHINE_REG_SERIAL_NUM_SCAN_FAILED = 5005 # error code changed from -18 to 5005



PACKAGE_TYPE_UPGRADE = 1
PACKAGE_TYPE_ROLLBACK = 2

logging_types = {"log_into_console":True, "log_into_file" : True} 
