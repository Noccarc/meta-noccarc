from evdev import InputDevice, categorize, ecodes
import evdev
from evdev.util import list_devices

from constants.app_macros import *
from subprocess import Popen, PIPE
import json
from utils.Request import Request
import utils.RequestQueue as RequestQueue
import time
import threading
import asyncio
import subprocess
from utils.monitor_log import logger


class BarcodeScanner():
    """
    Class        : fota_stm
    Inherits     :
    Description  : Main application class which is handling the ZMQ messages 
    """
    def __init__(self):
        """
        Function: __init__
        Description: init method of class
        @param:
        @return:
        """
        
        self.running = False
        self.devicePath = None
        
        self.name = "BARCODE_SCANNER"
        self.scancodes = {
                        # Scancode: ASCIICode
                            0: None, 1: u'ESC', 2: u'1', 3: u'2', 4: u'3', 5: u'4', 6: u'5', 7: u'6', 8: u'7', 9: u'8',
                            10: u'9', 11: u'0', 12: u'-', 13: u'=', 14: u'BKSP', 15: u'TAB', 16: u'q', 17: u'w', 18: u'e', 19: u'r',
                            20: u't', 21: u'y', 22: u'u', 23: u'i', 24: u'o', 25: u'p', 26: u'[', 27: u']', 28: u'CRLF', 29: u'LCTRL',
                            30: u'a', 31: u's', 32: u'd', 33: u'f', 34: u'g', 35: u'h', 36: u'j', 37: u'k', 38: u'l', 39: u';',
                            40: u'"', 41: u'`', 42: u'LSHFT', 43: u'\\', 44: u'z', 45: u'x', 46: u'c', 47: u'v', 48: u'b', 49: u'n',
                            50: u'm', 51: u',', 52: u'.', 53: u'/', 54: u'RSHFT', 56: u'LALT', 57: u' ', 100: u'RALT'
                        }
        self.capscodes = {
                            0: None, 1: u'ESC', 2: u'!', 3: u'@', 4: u'#', 5: u'$', 6: u'%', 7: u'^', 8: u'&', 9: u'*',
                            10: u'(', 11: u')', 12: u'_', 13: u'+', 14: u'BKSP', 15: u'TAB', 16: u'Q', 17: u'W', 18: u'E', 19: u'R',
                            20: u'T', 21: u'Y', 22: u'U', 23: u'I', 24: u'O', 25: u'P', 26: u'{', 27: u'}', 28: u'CRLF', 29: u'LCTRL',
                            30: u'A', 31: u'S', 32: u'D', 33: u'F', 34: u'G', 35: u'H', 36: u'J', 37: u'K', 38: u'L', 39: u':',
                            40: u'\'', 41: u'~', 42: u'LSHFT', 43: u'|', 44: u'Z', 45: u'X', 46: u'C', 47: u'V', 48: u'B', 49: u'N',
                            50: u'M', 51: u'<', 52: u'>', 53: u'?', 54: u'RSHFT', 56: u'LALT',  57: u' ', 100: u'RALT'
                        }   

    def readBarcode(self):
        """
        Function: readBarcode
        Description:  read barcode from barcode scanner module 
        @param devicePath string
        @return: 
        """
        
        dev = None
        result = ''
        local_err = None
        
        try:
            
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            
            dev = InputDevice(self.devicePath)
            dev.grab() # grab provides exclusive access to the device

           
            caps = False
            
            for event in dev.read_loop():
                if event.type == ecodes.EV_KEY:
                    data = categorize(event)  # Save the event temporarily to introspect it
                    if data.scancode == 42:
                        if data.keystate == 1:
                            caps = True
                        if data.keystate == 0:
                            caps = False

                    if data.keystate == 1:  # Down events only
                        if caps:
                            key_lookup = u'{}'.format(self.capscodes.get(data.scancode)) or u'UNKNOWN:[{}]'.format(data.scancode)  # Lookup or return UNKNOWN:XX
                        else:
                            key_lookup = u'{}'.format(self.scancodes.get(data.scancode)) or u'UNKNOWN:[{}]'.format(data.scancode)  # Lookup or return UNKNOWN:XX


                        if (data.scancode != 42) and (data.scancode != 28):
                            result += key_lookup

                        if(data.scancode == 28):
                            break
            
            dev.close()
        
        except OSError as err:
            if err.errno == 19:
                logger.log_error(self.name,"Error: No such device. Please verify that the device is connected and configured correctly.")
                result, local_err = None, "device not connected"
            
            else:
                # handle other types of OSError
                logger.log_error(self.name,f"OSError:{err}")
                result, local_err = None, "failed"
                   
        except:
            result, local_err = None, "failed"
        
        
        return result, local_err
                       
    def detectBarcodeScanner(self):
        """
        Function: detectBarcodeScanner
        Description:  it detect the barcode scanner module which usb moudle is plugged in 
        @return: 
        """
        
        # create a set to track currently connected barcode scanners
        connected_scanners = set()

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        # get a list of connected input devices
        input_devices = [evdev.InputDevice(path) for path in list_devices()]

        for input_device in input_devices:
           # logger.log_info(self.name,input_device.path, input_device.name)
            if input_device.name=="HID 0581:011c" and input_device.name not in connected_scanners:
                logger.log_info(self.name,f"scanner module connected :{input_device.path}")
                self.devicePath = input_device.path
                break
        
        
        # process = Popen([BARCODE_SCANNER_MODULE_DETECTION_COMMAND],stdout=PIPE, stderr=PIPE, shell=True)
        # stdout, stderr = process.communicate()
        
        # if stdout:
        #     return True

        # else:
        #     return False
        
        if(self.devicePath):
            return True
        else:
            return False
    
    def sendRequest(self, url, ok, msg, data={}, statusKey = SUCCESS):
        req = Request()
        
        req.url = url
        req.ok = ok
        req.message = msg
        req.data = data
        req.data[STATUS_KEY] = statusKey
    
        RequestQueue.setRequest(req)
             
    def work(self):
                
        while True:
            if(self.detectBarcodeScanner()):
                break
            time.sleep(0.5)
            
        #  send response usb detection to backend
        self.sendRequest("BarcodeScanner/USBdetection", True, "", {"usb_detection" : True})
        logger.log_info(self.name,"USB detected")
        
        readSerialNo, err = self.readBarcode()
        
        if err:
            # send failure to backend -> continue again
            self.sendRequest("BarcodeScanner/serialNumber", False, "read serial number failed", {}, ERROR_CODE_MACHINE_REG_SERIAL_NUM_SCAN_FAILED)
            logger.log_error(self.name,f"readBarcode error : {err}") #changed
        else:
            # send failure to backend -> continue again
            self.sendRequest("BarcodeScanner/serialNumber", True, "", {"serialNumber": readSerialNo})
            # self.sendRequest("BarcodeScanner/serialNumber", False, "serial number verification failed", {}, ERROR_CODE_MACHINE_REG_SERIAL_NUM_SCAN_FAILED)
            logger.log_error(self.name,"serialNumber verification failed")
        self.running = False

    def run(self):
        if not self.running:
            self.running = True
            th_object = threading.Thread(target=self.work)
            th_object.start()
                   
    def verfySerialNO(self, serialNo):       
        if len(serialNo) == 22 and serialNo[:3] == "V03":
            return True
        return False
                
       
                
barcodeScannerObj = BarcodeScanner()


                           
