import threading
import utils.RequestQueue as RequestQueue
import services.bar_code_scanner as bar_code_scanner
from config.router_communication import RouterComObj
from constants.app_macros import *
from services.fota_stm import fota_stm
from utils.monitor_log import logger

class Main:
    
    def __init__(self):
        self.FotaStm = None
        self.name = "MAIN_FOTA_STM"
    
    def parse_request(self, req):
        if req.urlMatch("BarcodeScanner/USBdetection"):
            # send to router
            logger.log_info(self.name,f"{req.ok} {req.message} {req.data}")
            
            dJSONMsg = {}
            dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
            dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
            dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_SCANNER_MODULE_USB_CONNECT_STATUS
            dJSONMsg[STATUS_KEY] = req.data[STATUS_KEY]
            
            req.data[STATUS_KEY] = None
            dJSONMsg[DATA_KEY] = req.data
            
            RouterComObj.send_data(dJSONMsg)
            
        elif req.urlMatch("BarcodeScanner/serialNumber"):
            logger.log_info(self.name,f"{req.ok} {req.message} {req.data}")
            
            dJSONMsg = {}
            dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
            dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
            dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_SCANNER_MODULE_SERIAL_NUMBER_STATUS
            dJSONMsg[STATUS_KEY] = req.data[STATUS_KEY]
            
            req.data[STATUS_KEY] = None
            dJSONMsg[DATA_KEY] = req.data
            
            RouterComObj.send_data(dJSONMsg)
        
        elif req.urlMatch("router/request"):
            self.FotaStm.parseZmqRouterRequest(req.data)
         
    def work(self):
        while True:
            try:
                # logger will first clear log 
                logger.clear_log_when_full()    
                req = RequestQueue.getRequest()
                self.parse_request(req)
                
            except Exception as e:
                logger.log_info(self.name,f" exception : ".format(e))
    
    def run(self):
        self.FotaStm = fota_stm()        
        RouterComObj.run()
        
        th_object = threading.Thread(target=self.work)
        th_object.start()
        th_object.join()
        

if __name__ == "__main__":
    main = Main()
    main.run()
    logger.log_info(main.name,"main exit")
    
