import logging
import inspect
import os

"""
Description: LogManager
             Here developer can customise the logging module. You can also monitor logs or enhance the logging
"""
 # Custom log level
logging.SUCCESS = 25  # Arbitrary integer value for SUCCESS log level
logging.addLevelName(logging.SUCCESS, 'SUCCESS')  # Naming the custom log level

# custom Formatter for logger
class CustomLoggerFormatter(logging.Formatter):

    orange = '\x1b[38;5;208m'
    blue = '\x1b[38;5;39m'
    yellow = "\x1b[33;20m"
    red = "\x1b[31;20m"
    green = "\x1b[32;20m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"
    bold_green = "\x1b[1;32m"


    format = "%(asctime)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"

    FORMATS = {
        logging.DEBUG: f"{orange}{format}{reset}",
        logging.INFO: f"{blue}{format}{reset}",
        logging.WARNING: f"{yellow}{format}{reset}",
        logging.ERROR: f"{red}{format}{reset}",
        logging.CRITICAL: f"{bold_red}{format}{reset}",
        logging.SUCCESS: f"{bold_green}{format}{reset}"
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)

#  log manager 
class LogManager:

    def __init__(self):
        # getting Logger
        self.logger = logging.getLogger("MainLogger")
        self.logger.setLevel(logging.DEBUG)  # Set the logger level
        self.log_file = 'fota_stm.log'

        # Create handlers
        console_handler = logging.StreamHandler()  # Display log in the console
        file_handler = logging.FileHandler(self.log_file)  # Send log to a file

        # Set log levels for handlers
        console_handler.setLevel(logging.INFO)
        file_handler.setLevel(logging.DEBUG)

        # Create formatter and add it to handlers
        formatter = CustomLoggerFormatter()
        console_handler.setFormatter(formatter)
        file_handler.setFormatter(formatter)

        # Add handlers to logger
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)

    # log info message 
    def log_info(self, module_name, message):
        func_name = inspect.currentframe().f_back.f_code.co_name
        self.logger.info(f'[{module_name}] - {func_name} - {message}')

    # log warning message 
    def log_warning(self,module_name,message):
        func_name = inspect.currentframe().f_back.f_code.co_name
        self.logger.warning(f'[{module_name}] - {func_name} - {message}')

    # log error message 
    def log_error(self, module_name, error):
        func_name = inspect.currentframe().f_back.f_code.co_name
        self.logger.error(f'[{module_name}] - {func_name} - {error}')

    # log critical message
    def log_critical(self, module_name, message):
        func_name = inspect.currentframe().f_back.f_code.co_name
        self.logger.critical(f'[{module_name}] - {func_name} - {message}')

    # log success message
    def log_success(self, module_name, message):
        func_name = inspect.currentframe().f_back.f_code.co_name
        self.logger.log(logging.SUCCESS,f'[{module_name}] - {func_name} - {message}')

    # clearing up log history
    def clear_log_when_full(self, max_file_size_bytes=1024*1024*200):  # Set your desired maximum file size in bytes
        log_file_path = 'fota_stm.log'  # Replace this with your log file path
        if os.path.exists(self.log_file):
            current_file_size = os.path.getsize(log_file_path)
            if current_file_size > max_file_size_bytes:
                with open(log_file_path, 'w'):  # Open the file in 'write' mode to clear its content
                    pass
                self.logger.warning(f'Log file cleared as it reached {current_file_size} bytes')
            else:
                self.logger.warning(f"Log file current size : {current_file_size} has not reached max size : {max_file_size_bytes}")


# logger object 
# exporting this object , directly import from another module.
logger = LogManager()