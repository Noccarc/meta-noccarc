"""
 FileName      : fota_stm.py

 Description   : This file contains the implementation of FOTA_STM ZMQ dealer. which is reponsible to handle
                 all the incoming message from the Router application. Also sent response to that perticular message
                 with data. Main task of this application is to install the newly received OTA package in to the device 
 Version : 

 Author    : Noccarc

"""
import threading
import zmq
import subprocess 
import json
from json.decoder import JSONDecodeError
import logging
import logging.handlers
import traceback
import sys
from constants.app_macros import *
import time
import socket
import hashlib
import os
import zipfile
import shutil
from distutils.dir_util import copy_tree
import stat
from services.bar_code_scanner import barcodeScannerObj
from config.router_communication import RouterComObj
from utils.monitor_log import logger


# ---- update constants -------
MSG_TYPE_PKG_UPGRADE_OS = 50

MSG_TYPE_PKG_UPGRADE_SOFTWARE = 51

MSG_TYPE_PKG_UPGRADE_BOTH_SOFTWARE_OS = 52

MSG_TYPE_PKG_ROLLBACK_SOFTWARE = 10

 

class fota_stm():
    """
    Class        : fota_stm
    Inherits     :
    Description  : Main application class which is handling the ZMQ messages 
    """
    def __init__(self):
        """
        Function: __init__
        Description: init method of class
        @param:
        @return:
        """
        threading.Thread.__init__(self)
        self.name = "FOTA_STM"
        
    # --------------------------------- HELPER FUNCTIONALITITES ----------------------------------
    def send_data(self, dJSONMsg):
        RouterComObj.send_data(dJSONMsg)

    def keys_exists(self, dJSONMsg, *strKeys):
        """
        Function: send_data
        Description: Check if *strKeys (nested) exists in input dJSONMsg (dict).
        @param dJSONMsg: JSON dictonary
        @param strKeys: JSON Keys
        @return: True if key exists otherwise false
        """
        try:
            if not isinstance(dJSONMsg, dict):
                logger.log_error(self.name,'keys_exists() expects dict as first argument.')
                return False
            if len(strKeys) == 0:
                logger.log_error(self.name,'keys_exists() expects at least two arguments, one given.')
                return False

            _element = dJSONMsg
            for key in strKeys:
                try:
                    _element = _element[key]
                except KeyError:
                    return False
        except Exception as e:
            logger.log_error(self.name,"Failed to check key exists in dictonary: {0} error: {1}".format(dJSONMsg,e))
            logger.log_error(self.name,traceback.format_exc())
            return False

        return True

    def getMD5SUMofFile(self, strFileName):
        strMD5SUM = None
        try:
            with open(strFileName, 'rb') as file_to_check:
                # TODO: Need to think file read logic in case of file is big
                # read contents of the file
                data = file_to_check.read()    
                # pipe contents of the file through
                strMD5SUM = str(hashlib.md5(data).hexdigest())
        except Exception as e:
            logger.log_error(self.name,"Failed to calculate the MD5SUM of file: {0} error: {1}".format(strFileName,e))
            logger.log_error(self.name,traceback.format_exc())
        return strMD5SUM

    def checkFiles(self,fileType):
        bReturnStatus = False
        basePath = "/usr/local/zmq/FOTA_STM"
        for key in fileType:
                    newPath = os.path.join(basePath, str(""))
                    path = os.path.join(newPath,fileType[key])
                    if(True != os.path.exists(os.path.join(newPath,fileType[key]))):
                            logger.log_error(self.name,"{0} is not available in OTA package".format(key))
                            bReturnStatus = False
                            break
                    else:
                            bReturnStatus = True
        return bReturnStatus

    def createSCPArgs(self,fileObj):
        SCPArgs = ""
        fileLocation = fileObj["location"]
        fileList = fileObj["files"]
        SCPArgs = "root@" + IOMT_IP_ADDRESS + ":" + str(fileLocation) #production
        if SCPArgs!="":
            logger.log_info(self.name,f"-------- Successfully created scpArgs: {SCPArgs}")
            return SCPArgs
        else:
            logger.log_info(self.name,"Unable to create SCPArgs. Please check your configuration.")
            return SCPArgs

    def checkZIP(self,file_path):
        #implement a timeout here using signal #######################################################################
        try:
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                zip_ref.testzip()
                return True
        except zipfile.BadZipFile:
            return False    
    
    def extractZIP(self, sourcePath , destinationPath):
        try:
            with zipfile.ZipFile(sourcePath, 'r') as zip_ref:
                zip_ref.extractall(destinationPath)
            return True
        except zipfile.BadZipFile as e:
            logger.log_error(self.name,f"Unable to extract File. Error: {e}")
            return False  
    
    def changeFileName(self,fileMappingObj,destinationPath):
        rStatus = False
        try:
            for old_name, new_name in fileMappingObj.items():
                old_path = os.path.join(destinationPath, old_name)
                new_path = os.path.join(destinationPath, new_name)
                shutil.move(old_path, new_path)
            rStatus = True    
        except Exception as e:
            logger.log_error(self.name,f"Failed to rename files . Error : {e} ")
            rStatus = False
            
        return rStatus
    
    def createStmSCPArgs(self,fileObj):
        osSCPArgs = ""
        appSCPArgs = ""
        install_file_SCPArgs = ""
        
        # os file 
        if "osDependentFilePath" in fileObj["location"]:
            osFileLocation = fileObj["location"]["osDependentFilePath"]
            osSCPArgs = "root@" + IOMT_IP_ADDRESS + ":" + str(osFileLocation) # production
        
        # install file 
        if "installFilePath" in fileObj["location"]:
            installFileLocation = fileObj["location"]["installFilePath"]
            install_file_SCPArgs = "root@" + IOMT_IP_ADDRESS + ":" + str(installFileLocation) # production
        
        # app file 
        if "appFilePath" in fileObj["location"]:
            latest_app_file = fileObj["location"]["appFilePath"]
            appSCPArgs = "root@" + IOMT_IP_ADDRESS + ":" + str(latest_app_file) # production 

        if osSCPArgs!="" or appSCPArgs!="" or  install_file_SCPArgs!="" :
            logger.log_info(self.name,f"----------- Successfully created scp arguments.")
            return osSCPArgs,appSCPArgs,install_file_SCPArgs
        else:
            logger.log_info(self.name,"Unable to create SCPArgs. Please check your configuration.")
            return osSCPArgs,appSCPArgs,install_file_SCPArgs
    
    def checkUpdateStatus(self,dirPath):
        rStatus = False
        if(os.path.exists(dirPath)):
            rStatus = True       
        return rStatus


    # --------------------------- SOFTWARE FILES FUNCTIONALITITES ---------------------------------

    def copySWFiles(self,strOTADirPath):
        """
        Description: This function copies the new backend and new UI from downloaded location to original location. 
                     return True if both files are successfully copied
                     return False if both files are not able to copied.
        """
        rTransferStatus = False
        backendTransferStatus = False
        uiTransferStatus = False
        base_directory = "/usr/local/HMIfiles/apps/"
        originalUIPath  = os.path.join(SOFTWARE_UI_PATH_IN_DEVICE,str("Noccarc_UI")) # path : /usr/local/HMIfiles/apps/Noccarc_UI

        # copy Backend File 
        if (os.path.exists(SOFTWARE_BACKEND_PATH_IN_DEVICE)):

            OldBackendDir = os.path.join(base_directory, "Noccarc_Backend") # Noccarc_Backend --> oldBackendDir(means currently running backend in system.) .  Path -> /usr/local/HMIfiles/apps/Noccarc_Backend
            NewBackendDir = os.path.join(base_directory, "Noccarc_Backend_Old")  # Noccarc_Backend_Old --> as newBackendDir
            oldBackendBinFile = os.path.join(OldBackendDir,"backend.bin")  # backend.bin ---> extracted file name 
            
            if (os.path.exists(NewBackendDir)):
                # if /Noccarc_Backend_Old exists already 
                logger.log_info(self.name,f"------------ Noccarc_Backend_Old Dir exists in location {NewBackendDir}.")
                logger.log_info(self.name,f"------------ Removing Noccarc_Backend_Old....")
                # remove it 
                shutil.rmtree(NewBackendDir)
                logger.log_info(self.name,f"------------ Removed Noccarc_Backend_Old successfully.")
                logger.log_info(self.name,f"------------ Again , Creating Noccarc_Backend_Old....")
                # create new 
                os.makedirs(NewBackendDir)
                logger.log_info(self.name,f"------------ Created Noccarc_Backend_Old  successfully.")

            elif (not os.path.exists(NewBackendDir)):
                logger.log_info(self.name,f"------------ Noccarc_Backend_Old Dir does not exists in location {NewBackendDir}")
                logger.log_info(self.name,"------------- Creating Noccarc_Backend_Old Dir ....")
                os.makedirs(NewBackendDir)
                logger.log_info(self.name,"------------- Created Noccarc_Backend_Old Dir successfully.")
           
            try:
                            if(os.path.exists(OldBackendDir)):
                                logger.log_info(self.name,"------------- Noccarc_Backend Dir is present ....")
                                logger.log_info(self.name,f"------------- Copying backend.bin from {OldBackendDir} to {NewBackendDir}........")
                                shutil.copy(oldBackendBinFile,NewBackendDir)
                                logger.log_info(self.name,f"----------- backend.bin copied successfully from {OldBackendDir} to {NewBackendDir}.")

                                logger.log_info(self.name,f"---------- Noccarc_Backend dir exist, starting to remove.....")
                                shutil.rmtree(OldBackendDir)
                                logger.log_info(self.name,"----------- Noccarc_Backend directory deleted successfully.")

                                if(not os.path.exists(OldBackendDir)):
                                    logger.log_info(self.name,"----------- Again , creating Noccarc_Backend directory to copy backend.bin in Noccarc_Backend ....")
                                    os.makedirs(OldBackendDir)
                                    logger.log_info(self.name,"----------- created Noccarc_Backend dir successfully.")

                                try:
                                    if(os.path.exists(SOFTWARE_BACKEND_PATH_IN_DEVICE)):
                                        logger.log_info(self.name,"----------- Now , Noccarc_Backend directory exists in system. Currently, this is empty dir. Initiating to copy new backend.bin in Noccarc_Backend....")

                                        strSourceFilePath = os.path.join(strOTADirPath, ota_pkg_files_locaiton["backend"])
                                        
                                        strDestinationPath = SOFTWARE_BACKEND_PATH_IN_DEVICE 

                                        logger.log_info(self.name,f"------------- start copying backend.bin from {strSourceFilePath} to {strDestinationPath} ...")
                                        shutil.copy(strSourceFilePath, strDestinationPath)
                                        logger.log_info(self.name,"-------------- backend.bin copied successfully.")

                                        logger.log_info(self.name,"--------- Verify step : checking backend.bin size....")
                                        strDestinationFilePath=os.path.join(strDestinationPath,str("backend.bin"))
                                        backendSourceFileSize = os.path.getsize(strSourceFilePath)
                                        backendDestinationFileSize = os.path.getsize(strDestinationFilePath)
                                        logger.log_info(self.name,f"source , dest ======= {backendSourceFileSize},{backendDestinationFileSize}")
                                        
                                        if(backendSourceFileSize!=backendDestinationFileSize):
                                            backendTransferStatus = False
                                            logger.log_error(self.name,"------- backend.bin file transfer failed. File is Corrupted. Verification Failed.")
                                        else:
                                            # copy successfull
                                            # then change permission of this backend.bin file 
                                            logger.log_info(self.name,"---------- changing backend.bin file Permission...")
                                            strBackendBinpath = os.path.join(strDestinationPath,str(BACKEND_BINARY_NAME))
                                            if(os.path.exists(strBackendBinpath)):
                                                st = os.stat(strBackendBinpath)
                                                os.chmod(strBackendBinpath, st.st_mode | stat.S_IEXEC)
                                                logger.log_info(self.name,"---------- backend.bin file permission changed successfully.")
                                            backendTransferStatus = True
                                            logger.log_info(self.name,"-------------- backend.bin copied successfully. Verified Successfully.")
                                    else:
                                        logger.log_error(self.name,"Noccarc_Backend does not exist")
                                    
                                except Exception as e:
                                    logger.log_error(self.name,f"Exception: {e}")
                            else:
                                logger.log_error(self.name,f"Backend.bin file does not exist")
            except Exception as e:
                            logger.log_error(self.name,f"Error deleting Noccarc_Backend directory:{e}")
        
        elif (not os.path.exists(SOFTWARE_BACKEND_PATH_IN_DEVICE)):
                    
                    logger.log_warning(self.name,f"---------- {SOFTWARE_BACKEND_PATH_IN_DEVICE} path does not exists in machine.")

                    logger.log_warning(self.name,f"---------- creating Noccarc_Backend dir ...")
                    # means /usr/local/HMIfiles/apps/Noccarc_Backend  does not exist then create that dir 
                    os.makedirs(SOFTWARE_BACKEND_PATH_IN_DEVICE,exist_ok=True)
                    logger.log_warning(self.name,f"---------- created Noccarc_Backend dir successfully.")
                    
                    strSourceFilePath = os.path.join(strOTADirPath, ota_pkg_files_locaiton["backend"])
                    strDestinationPath = SOFTWARE_BACKEND_PATH_IN_DEVICE
                    
                    logger.log_warning(self.name,f"---------- copying backend.bin from {strSourceFilePath} to {strDestinationPath}....")
                    shutil.copy(strSourceFilePath, strDestinationPath) # copy from source : /usr/local/zmq/FOTA_STM/Software/backend.bin    to    dest : /usr/local/HMIfiles/apps/Noccarc_Backend
                    logger.log_warning(self.name,f"---------- backend.bin copied successfully.")

                    strBackendBinpath = os.path.join(strDestinationFilePath,str("backend.bin"))

                    if(not os.path.exists(strBackendBinpath)):
                        logger.log_error(self.name,"--------- backend.bin file does not exist. Verification Failed.")
                        backendTransferStatus = False
                    else:    
                        logger.log_info(self.name,"---------- changing backend.bin file Permission...")
                        st = os.stat(strBackendBinpath)
                        os.chmod(strBackendBinpath, st.st_mode | stat.S_IEXEC)
                        logger.log_info(self.name,"---------- backend.bin file permission changed successfully.")

                        logger.log_info(self.name,"--------- Verify step : checking backend.bin size....")
                        backendSourceFileSize = os.path.getsize(strSourceFilePath)
                        backendDestinationFileSize = os.path.getsize(strBackendBinpath)
                        
                        if(backendSourceFileSize!=backendDestinationFileSize):
                            logger.log_error(self.name,"------- Backend File are not Transferred. Something went wrong!!! -----")
                            backendTransferStatus = False
                        else:
                            backendTransferStatus = True
                            logger.log_info(self.name,"-------------- backend.bin copied successfully. Verified Successfully.")

        # copy UI File 
        # /usr/local/HMIfiles/apps/Noccarc_UI
        if (os.path.exists(originalUIPath)):
                    logger.log_info(self.name,f"--------- Noccarc_UI dir present in path : {originalUIPath}")

                    newUIPath = os.path.join(base_directory,str("Noccarc_UI_Old")) # for having new Noccarc_UI update we will create path : /usr/local/HMIfiles/apps/Noccarc_UI_Old
                    
                    if(os.path.exists(newUIPath)):
                        logger.log_info(self.name,f"--------- Noccarc_UI_Old dir present in path : {newUIPath}. Removing Noccarc_UI_Old...")
                        # remove it 
                        shutil.rmtree(newUIPath)
                        logger.log_info(self.name,f"--------- Noccarc_UI_Old dir removed successfully.")

                    try:
                            logger.log_info(self.name,"--------- Backup Starts copying Noccarc_UI dir to Noccarc_UI_Old.....")
                            try:
                                shutil.copytree(originalUIPath,newUIPath)
                                logger.log_info(self.name,"------- Copied files from Noccarc_UI to Noccarc_UI_Old")
                            except Exception as e:
                                logger.log_error(self.name,f"Error Occured : {e} ")

                            logger.log_info(self.name,"-------- Noccarc_UI Dir exist, action for remove in next step. Removing Noccarc_UI ....")
                            shutil.rmtree(originalUIPath)
                            logger.log_info(self.name,"-------- Noccarc_UI directory deleted successfully!!")

                            try:
                                if(not os.path.exists(originalUIPath)):

                                    logger.log_info(self.name,"-------- Noccarc_UI Path not exists in machine currently. ")
                                    strSourceFilePath = os.path.join(strOTADirPath,ota_pkg_files_locaiton["UI"]) # /usr/local/zmq/FOTA_STM/Software/Noccarc_UI , Noccarc_UI is a directory 
                                    strDestinationPath = originalUIPath # /usr/local/HMIfiles/apps/Noccarc_UI
                                    try:
                                        logger.log_info(self.name,f"------- start copying new UI files from {strSourceFilePath} to {strDestinationPath} ...")
                                        shutil.copytree(strSourceFilePath, strDestinationPath)
                                        logger.log_info(self.name,"-------- new UI files transferred successfully. ")
                                    except Exception as e:
                                        logger.log_error(self.name,f"Error occured while copying the UI file : {e} ")

                                    logger.log_info(self.name,"--------- Verify step : checking Noccarc_UI size....")

                                    UIsourceFileSize = os.path.getsize(strSourceFilePath)
            
                                    UIdestinationFileSize =  os.path.getsize(strDestinationPath)
                                
                                    logger.log_info(self.name,f"UI Source ==> {UIsourceFileSize} , UI Dest  ==> {UIdestinationFileSize}")

                                    if(UIsourceFileSize!=UIdestinationFileSize):
                                            uiTransferStatus = False
                                            logger.log_error(self.name,"UI file transferred failed.Verification step failed.")
                                    else:
                                            logger.log_info(self.name,"------ New UI files are copied Successfully. Verfication Successfully.")
                                            uiTransferStatus = True

                            except Exception as e:
                                logger.log_error(self.name,f"Error : {e}")
                                
                    except Exception as e:
                        logger.log_error(self.name,f"Error : {e}")

        elif( not os.path.exists(originalUIPath)):
                    logger.log_warning(self.name,f"--------- Noccarc_UI is not present in path : {originalUIPath}.")

                    # copy files from FOTA_STM/Software to /usr/local/HMIfiles/apps
                    strSourceFilePath = os.path.join(strOTADirPath, ota_pkg_files_locaiton["UI"]) # /usr/local/zmq/FOTA_STM/Software/Noccarc_UI
                    strDestinationPath = SOFTWARE_BACKEND_PATH_IN_DEVICE #/usr/local/HMIfiles/apps/

                    logger.log_info(self.name,f"------------ copying new Noccarc_UI update from {strSourceFilePath} to {strDestinationPath}.....")
                    shutil.copytree(strSourceFilePath, strDestinationPath)
                    logger.log_info(self.name,"------------ New UI Copied Successfully.")

                    logger.log_info(self.name,"------------ Verfiy step : checking UI size.")
                    UIsourceFileSize = os.path.getsize(strSourceFilePath)
                    strDestinationFilePath = os.path.join(strDestinationPath,str("Noccarc_UI"))
                    UIdestinationFileSize =  os.path.getsize(strDestinationFilePath)                        
                    logger.log_info(self.name,f"UI Source  ==> {UIsourceFileSize} , UI Dest  ==> {UIdestinationFileSize}")

                    if(UIsourceFileSize!=UIdestinationFileSize):
                        uiTransferStatus = False
                        logger.log_error(self.name,"UI file transfer failed. Verification Failed.")
                    else:
                        logger.log_info(self.name,"------- UI Files are copied Successfully.Verfication successful.")
                        uiTransferStatus = True

        if(uiTransferStatus and backendTransferStatus):
             rTransferStatus = True 
             logger.log_success(self.name,"---------------- new UI and new Backend files are transferred successfully.")
             return rTransferStatus
        
        return rTransferStatus

    def useOldSWFiles(self):
        """
        Description: This function is triggered if in any case corrupt/mismatch/ happens.
                     This function will rename Noccarc_Backend_Old to Noccarc_Backend iff new backend files are not copied successfully.
                     This function will rename Noccarc_UI_Old to Noccarc_UI iff new UI files are not copied successfully.
        """
        try:
            base_directory = "/usr/local/HMIfiles/apps/"
            OldBackendDir = os.path.join(base_directory, "Noccarc_Backend")
            NewBackendDir = os.path.join(base_directory, "Noccarc_Backend_Old")
            originalUIPath  = os.path.join(SOFTWARE_UI_PATH_IN_DEVICE,str("Noccarc_UI"))
            newUIPath = os.path.join(base_directory,str("Noccarc_UI_Old"))

            # use old Backend -->
            logger.log_info(self.name,f"------- Backend File : removing file from path: {SOFTWARE_BACKEND_PATH_IN_DEVICE}...")
            shutil.rmtree(SOFTWARE_BACKEND_PATH_IN_DEVICE)
            logger.log_info(self.name,f"------- Backend File removed successfully from path : {SOFTWARE_BACKEND_PATH_IN_DEVICE}.")
            logger.log_info(self.name,f"------- Renaming Noccarc_Backend_Old to Noccarc_Backend.....")
            os.rename(NewBackendDir,OldBackendDir)
            logger.log_info(self.name,"-------- successfully renamed from Noccarc_Backend_Old to Noccarc_Backend")

            # use Old UI -->
            logger.log_info(self.name,f"-------- UI File : removing file from path : {originalUIPath}")
            shutil.rmtree(originalUIPath)
            logger.log_info(self.name,f"-------- UI File removed successfully from path : {originalUIPath}")
            logger.log_info(self.name,f"------- Renaming Noccarc_UI_Old to Noccarc_UI.....")
            os.rename(newUIPath,originalUIPath)
            logger.log_info(self.name,"------- successfully renamed from Noccarc_UI_Old to Noccarc_UI")
        except Exception as e:
            logger.log_error(self.name,f"Error: {e}")
    
    def copyFWFiles_Old(self,strOTADirPath):
        strSourcePath = ""
        strDestinationPath = ""
        rStatus = False
        # fwCopyTransferStatus = False
        masterStatus = False
        slaveStatus = False
        baseDir  = "/usr/local/VCB-OTA/OTA/"
        OldFirmwareDir = os.path.join(baseDir, "Firmware")
        NewFirmwareDir = os.path.join(baseDir, "Firmware_Old")

        if(os.path.exists(OldFirmwareDir)):

            if(os.path.exists(NewFirmwareDir)):

                logger.log_info(self.name,"Firmware_Old Dir exists")
                logger.log_info(self.name,"Removingg Firmware_Old Dir....")
                shutil.rmtree(NewFirmwareDir)
                logger.log_info(self.name,"Removed Firmware_Old Dir successfully!!")
                os.makedirs(NewFirmwareDir,exist_ok=True)

            elif (not os.path.exists(NewFirmwareDir)):
                        logger.log_info(self.name,"Creating Firmware_Old Dir...")
                        os.makedirs(NewFirmwareDir,exist_ok=True)
            
            try:
                if(os.path.exists(OldFirmwareDir)):
                    masterFilePath = os.path.join(OldFirmwareDir,"Master.hex")
                    slaveFilePath = os.path.join(OldFirmwareDir,"Slave.hex")

                    shutil.copy(masterFilePath,NewFirmwareDir)
                    logger.log_info(self.name,"Master File copied from Firmware to Firmware_Old directory")

                    shutil.copy(slaveFilePath,NewFirmwareDir)
                    logger.log_info(self.name,"Slave File copied from Firmware to Firmware_Old directory")

                    logger.log_info(self.name,"Firmware Dir exists , action for remove in next step...")
                    shutil.rmtree(OldFirmwareDir)
                    logger.log_info(self.name,"Firmware Dir deleted successfully.")

                try:
                    if(not os.path.exists(OldFirmwareDir)):
                        
                        logger.log_info(self.name,"Firmware Dir not exists")
                        logger.log_info(self.name,"Creating Firmware Dir")
                        os.makedirs(OldFirmwareDir,exist_ok=True)
                        logger.log_info(self.name,"Created Successfully")

                        # copy master 
                        strSourcePath = os.path.join(strOTADirPath,ota_pkg_files_locaiton["Master"])
                        master_file_size_before_copy = os.path.getsize(strSourcePath)
                        strDestinationPath  =  OldFirmwareDir
                        logger.log_info(self.name,f"start copying Master file from {strSourcePath} to {strDestinationPath}................")
                        try:
                            if os.path.exists(strSourcePath):
                                shutil.copy(strSourcePath, strDestinationPath)
                                logger.log_info(self.name,f"--------- Master File copied successfully.")
                                # error 
                                master_file_size_after_copy = os.path.getsize(os.path.join(baseDir, ota_pkg_files_locaiton["Master"])) 
                                logger.log_info(self.name,f"--------- Verification Step : Master File size before copy : {master_file_size_before_copy}")
                                logger.log_info(self.name,f"--------- Verification Step : Master File size after copy : {master_file_size_after_copy}")
                                if master_file_size_after_copy == master_file_size_before_copy:
                                    masterStatus = True
                                    logger.log_info(self.name,"------- Master File transferred successfully. Verification successful.")
                            else:
                                logger.log_error(self.name,f"--- Master : {strSourcePath} does not exists.")
                        except Exception as e:
                            logger.log_error(self.name,f"Error occured while copying the Master file :{e}")

                        # copy slave
                        strSourcePath = os.path.join(strOTADirPath,ota_pkg_files_locaiton["Slave"])
                        slave_file_size_before_copy = os.path.getsize(strSourcePath)
                        logger.log_info(self.name,"start copying Slave file ................")
                        try:
                            if os.path.exists(strSourcePath):
                                shutil.copy(strSourcePath, strDestinationPath)
                                logger.log_info(self.name,f"--------- slave File copied successfully.")
                                # error
                                slave_file_size_after_copy = os.path.getsize(os.path.join(baseDir, ota_pkg_files_locaiton["Slave"]))
                                logger.log_info(self.name,f"--------- Verification Step : Slave File size before copy : {slave_file_size_before_copy}")
                                logger.log_info(self.name,f"--------- Verification Step : Slave File size after copy : {slave_file_size_after_copy}")

                                if slave_file_size_after_copy == slave_file_size_before_copy:
                                    slaveStatus = True
                                    logger.log_info(self.name,"------ Slave File transferred successfully. Verification successful.")
                            else:
                                logger.log_error(self.name,f"--- Slave : {strSourcePath} does not exists.")
                        except Exception as e:
                            logger.log_error(self.name,f"Error occured while copying the Slave file : {e}")
                        
                        # logger.info("checking file Size....")

                        # strSourceFilePath = os.path.join(strOTADirPath,"Firmware")
                        # FirmwareSourceFileSize = os.path.getsize(strSourceFilePath)
                        # FirmwareDestFileSize =  os.path.getsize(strDestinationPath)
                        # logger.info(f"Firmware Source Bytes ==> {FirmwareSourceFileSize} , Firmware Dest Bytes ==> {FirmwareDestFileSize}")

                        # if(FirmwareSourceFileSize!=FirmwareDestFileSize):   
                        #     logger.error("Firmware Files transfer Failed")
                        #     fwCopyTransferStatus = False
                        # else:
                        #     logger.info("Firmware Files are copied Successfully")
                        #     fwCopyTransferStatus = True
                except Exception as e:
                    logger.log_error(self.name ,f"Error occured : {e}")

            except Exception as e:
                logger.log_error(self.name,f"Error occured while copying files : {e}") 
        else:
            logger.log_error(self.name,f"Firmware Dir does not exists. : {e}")
            masterStatus = False
            slaveStatus = False
            rStatus = False

        if((masterStatus and slaveStatus)):
            rStatus = True
            logger.log_success(self.name,"Master and Slave Transferred successfully")
            
        return rStatus

    def copyFWFiles(self,strOTADirPath):
        """
        Description: This function copies the new firmware  from downloaded location to original location. 
                     return True if both firmware files are successfully copied
                     return False if both firmware files are not able to copied.
        """
        strSourcePath = ""
        strDestinationPath = ""
        rStatus = False
        masterStatus = False
        slaveStatus = False
        baseDir  = "/usr/local/VCB-OTA/OTA/"
        OldFirmwareDir = os.path.join(baseDir, "Firmware") # current Firmware directory , path :/usr/local/VCB-OTA/OTA/Firmware
        NewFirmwareDir = os.path.join(baseDir, "Firmware_Old") # backup Firmware directory , path : /usr/local/VCB-OTA/OTA/Firmware_Old

        if(os.path.exists(OldFirmwareDir)):
            logger.log_info(self.name,f"--------- Firmware Dir exists in path {OldFirmwareDir}.")

            if(os.path.exists(NewFirmwareDir)):
                logger.log_info(self.name,f"-------- Firmware_Old Dir exists in path {NewFirmwareDir}.")
                logger.log_info(self.name,"--------- Removing Firmware_Old Dir....")
                shutil.rmtree(NewFirmwareDir)
                logger.log_info(self.name,"--------- Removed Firmware_Old Dir successfully.")
                logger.log_info(self.name,"--------- Again, creating Firmware_Old Dir....")
                os.makedirs(NewFirmwareDir,exist_ok=True)
                logger.log_info(self.name,"--------- created Firmware_Old dir sucessfully.")

            elif (not os.path.exists(NewFirmwareDir)):
                        logger.log_info(self.name,"--------- Creating Firmware_Old Dir...")
                        os.makedirs(NewFirmwareDir,exist_ok=True)
                        logger.log_info(self.name,"--------- created Firmware_Old dir sucessfully.")
            
            try:
                if(os.path.exists(OldFirmwareDir)):
                    
                    logger.log_info(self.name,f"--------- Firmware Dir exists in path {OldFirmwareDir}.")

                    masterFilePath = os.path.join(OldFirmwareDir,"Master.hex")
                    slaveFilePath = os.path.join(OldFirmwareDir,"Slave.hex")

                    logger.log_info(self.name,f"--------- copying Master.hex from path {masterFilePath} to {NewFirmwareDir}.")
                    shutil.copy(masterFilePath,NewFirmwareDir)
                    logger.log_info(self.name,"---------- Master File copied successfully from Firmware dir to Firmware_Old directory.")

                    logger.log_info(self.name,f"--------- copying Slave.hex from path {slaveFilePath} to {NewFirmwareDir}.")
                    shutil.copy(slaveFilePath,NewFirmwareDir)
                    logger.log_info(self.name,"---------- Slave File copied successfully from Firmware dir to Firmware_Old directory.")

                    logger.log_info(self.name,"---------- Firmware Dir exists , action for remove. Removing .......")
                    shutil.rmtree(OldFirmwareDir)
                    logger.log_info(self.name,"---------- Firmware Dir deleted successfully.")

                try:
                    if(not os.path.exists(OldFirmwareDir)):
                        
                        logger.log_info(self.name,f"-------- Firmware Dir not exists in path {OldFirmwareDir}")
                        logger.log_info(self.name,"-------- Again, Creating Firmware Dir....")
                        os.makedirs(OldFirmwareDir,exist_ok=True)
                        logger.log_info(self.name,"-------- Created Successfully")
                        strDestinationPath  =  OldFirmwareDir

                        # copy master 
                        try:
                            strMasterSourcePath = os.path.join(strOTADirPath,ota_pkg_files_locaiton["Master"])
                            
                            master_file_size_before_copy = os.path.getsize(os.path.join(strOTADirPath,ota_pkg_files_locaiton["Master"]))

                            logger.log_info(self.name,f"--------- copying new Master file from {strMasterSourcePath} to {strDestinationPath}...")
                            shutil.copy(strMasterSourcePath, strDestinationPath)
                            logger.log_info(self.name,f"--------- Successfully copied new Master file from {strMasterSourcePath} to {strDestinationPath}.")

                            master_file_size_after_copy = os.path.getsize(os.path.join(baseDir,ota_pkg_files_locaiton["Master"]))

                            logger.log_info(self.name,f"--------- Verification Step : Master File size before copy : {master_file_size_before_copy}")
                            logger.log_info(self.name,f"--------- Verification Step : Master File size after copy : {master_file_size_after_copy}")
                            if master_file_size_after_copy == master_file_size_before_copy:
                                masterStatus = True
                                logger.log_info(self.name,"------- Master File transferred successfully. Verification successful.")

                        except Exception as e:
                            logger.log_error(self.name,f"Error occured while copying the Master file : {e}")

                        # copy slave
                        try:
                            strSlaveSourcePath = os.path.join(strOTADirPath,ota_pkg_files_locaiton["Slave"])
                            slave_file_size_before_copy = os.path.getsize(strSlaveSourcePath)

                            logger.log_info(self.name,f"--------- copying new slave file from {strSlaveSourcePath} to {strDestinationPath}...")
                            shutil.copy(strSlaveSourcePath, strDestinationPath)
                            logger.log_info(self.name,f"--------- Successfully copied new slave file from {strSlaveSourcePath} to {strDestinationPath}.")

                            slave_file_size_after_copy = os.path.getsize(os.path.join(baseDir,ota_pkg_files_locaiton["Slave"]))

                            logger.log_info(self.name,f"--------- Verification Step : Slave File size before copy : {slave_file_size_before_copy}")
                            logger.log_info(self.name,f"--------- Verification Step : Slave File size after copy : {slave_file_size_after_copy}")

                            if slave_file_size_after_copy == slave_file_size_before_copy:
                                slaveStatus = True
                                logger.log_info(self.name,"------ Slave File transferred successfully. Verification successful.")
                        except Exception as e:
                            logger.log_error(self.name,f"Error occured while copying the Slave file {e}")
                        
                except Exception as e:
                    logger.log_error(self.name,f"Error occured {e}")

            except Exception as e:
                logger.log_error(self.name,"Error occured while copying files") 
        else:
            logger.log_error(self.name,"Firmware Dir does not exists.")
            masterStatus = False
            slaveStatus = False
            rStatus = False

        if(masterStatus and slaveStatus):
            rStatus = True
            logger.log_success(self.name,"---------- Firmware Files Transfer Successful.")
            
        return rStatus
        
    def useOldFWFiles(self):
        """
        Description : This function will be triggered when there is some issue in file transer or either file gets corrupt/mismatch
                      This function will rename Firmware_Old to Firmware.
        """
        try:
            baseDir  = "/usr/local/VCB-OTA/OTA/"
            OldFirmwareDir = os.path.join(baseDir, "Firmware")
            NewFirmwareDir = os.path.join(baseDir, "Firmware_Old")

            logger.log_info(self.name,f"--------- Firmware dir : removing start from path : {FIRMWARE_PATH_IN_DEVICE}...")
            shutil.rmtree(FIRMWARE_PATH_IN_DEVICE)
            logger.log_info(self.name,f"--------- Firmware dir removed from path.{FIRMWARE_PATH_IN_DEVICE}")

            logger.log_info(self.name,"--------- Renaming Firmware_Old to Firmware ....")
            os.rename(NewFirmwareDir,OldFirmwareDir)
            logger.log_info(self.name,"--------- successfully , renamed from Firmware_Old to Firmware")

        except Exception as e:
            logger.log_error(self.name,f"Error : {e}")

    # ---------------------------------- FIRMWARE FUNCTIONALITIES ---------------------------------
    def check_connection(self):
        """
        Description: This function checks the hardware connection required for firmware compatibility.
        """
        rStatus = False
        retryCount = 3
        command = "echo 100 > /sys/class/leds/jtag/brightness"
        fpath = "/sys/class/leds/jtag/brightness"
        lsusb_command = "lsusb"
        verfifyCodeCmnd = "cat /sys/class/leds/jtag/brightness"

        if os.path.exists(fpath):
            while(retryCount>0):
                result = subprocess.run(command, shell=True,capture_output=True, text=True)
                vcode = subprocess.run(verfifyCodeCmnd,shell=True,capture_output=True, text=True)
                vcode = int(vcode.stdout.strip())

                if(result.returncode==0 and vcode == 100):
                    logger.log_info(self.name,"---- FDTI is enabled. -----")
                    rStatus = True
                    break
                retryCount = retryCount - 1

            if(rStatus==False):
                logger.log_error(self.name,"check Hardware Connection!!")
                return rStatus
        else:
            logger.log_error(self.name,"{0} does not exists.".format(fpath))
        
        #delay
        time.sleep(1)

        # additionalLogs 
        if rStatus:
            # Run lsusb command to check FTDI status
            lsusb_result = subprocess.run(lsusb_command, shell=True, capture_output=True, text=True)
            if lsusb_result.returncode == 0:
                logger.log_info(self.name,"lsusb output:")
                logger.log_info(self.name,lsusb_result.stdout)
            
        return rStatus

    def run_cfg_files(self):
        """
        Description : [Not in use]
        """
        # ----- Dont change the configuration. Contact NOCCARC ---
        rStatus = False
        WORK_DIR = '/usr/local/VCB-OTA/OTA/xpack-openocd-0.11.0-2/bin'
        try:
            logger.log_info(self.name,"======================= VCB Update Begin ==================")

            # change working dir
            os.chdir(WORK_DIR)

            # Run the openocd command
            openocd_command = [
                './openocd',
                '-d2',
                '-f', '../scripts/interface/ftdi/dp_busblaster_kt-link.cfg',
                '-f', '../scripts/board/stm32nocca.cfg',
                '-f', '../scripts/board/VCB_check.cfg'
            ]

            # executing cmnd 
            result = subprocess.run(openocd_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

            if result.returncode == 0:
                logger.log_info(self.name,"OpenOCD command executed successfully")
                rStatus = True
            else:
                error_output = result.stderr
                if "no device found" in error_output:
                    logger.log_error(self.name,"Error: No device found. Check your hardware connection.")
                elif "unable to open ftdi device" in error_output:
                    logger.log_error(self.name,"Error: Unable to open FTDI device. Verify the device settings and drivers.")
                rStatus = False

            logger.log_info(self.name,"======================= VCB Update End ====================")

            # Sleep for 2 seconds
            time.sleep(2) 

        except Exception as e:
            # Handle other errors
            logger.log_error(self.name,f"Error: {e}")
        
        return rStatus

    def verfiy_firmware(self):
        """
        Description: This function will verify whether there is hardware connection for firmware is present or not in the device.
                     returns False if there is no hardware connection
                     return True if there is hardware connection
        """
        verfiyStatus = False
        # check whether ftdi is enabled or not 
        # if not try to enable ftdi 
        if(self.check_connection() == True):
            logger.log_info(self.name,"----  firmware connection check successful. ----")
            verfiyStatus = True
            # #[ NOT NEEDED] : step 2: run the cfg files 
            # if(self.run_cfg_files()== True):
            #     verfiyStatus = True
            # else:
            #     logger.log_error(self.name,"not able to run cfg files")
        else:
            logger.log_error(self.name,"check hardware connection.")

        return verfiyStatus
    
    def reset_firmware(self):
        """
        Description : This function executes similar command to flash firmware. Here it just reset the firmware. 
        """
        #-------- DON'T CHANGE THE CONFIGURATION. CONTACT NOCCARC -----
        WORK_DIR = '/usr/local/VCB-OTA/OTA/xpack-openocd-0.11.0-2/bin'
        
        logger.log_info(self.name,"======================= Reset Firmware : VCB Update Begin ====================")
        try:
            # Change directory to WORK_DIR
            os.chdir(WORK_DIR)
            
            resetCmnd = ['./openocd', '-d2', '-f', '../scripts/interface/ftdi/dp_busblaster_kt-link.cfg', '-f', '../scripts/board/stm32nocca.cfg', '-f', '../scripts/board/VCB_reset.cfg']

            # Execute openocd with the specified command line options
            result = subprocess.run(resetCmnd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        
            if result.returncode == 0:
                logger.log_success(self.name,"------OpenOCD command executed successfully-----")     
            else:
                error_output = result.stderr
                if "no device found" in error_output:
                    logger.log_error(self.name,"Error: No device found. Check your hardware connection.")
                        
                elif "unable to open ftdi device" in error_output:
                    logger.log_error(self.name,"Error: Unable to open FTDI device. Verify the device settings and drivers.")
                    
            logger.log_info(self.name,"======================= Reset Firmware : VCB Update End ====================")

        except subprocess.CalledProcessError as e:
            logger.log_error(self.name,f"Error executing command: {e}")
            
    def flash_firmware(self,iRetry_count):
        """
        Description: This function will flash firmware . Maybe one time it can get failed so Currently it have set to Retry count = 3 
        return True if firmware was successfully flashed.
        return False if firmware was not able to flash.
        """
        time.sleep(5) #delay 
        logger.log_info(self.name,"Firmware Flashing started ...!")
        try:
                logger.log_info(self.name,"======================= VCB Update Begin 123 ====================")
                WORK_DIR = '/usr/local/VCB-OTA/OTA/xpack-openocd-0.11.0-2/bin'

                # Change the working directory
                os.chdir(WORK_DIR)

                # Run the openocd command
                openocd_command = [
                    './openocd',
                    '-d2',
                    '-f', '../scripts/interface/ftdi/dp_busblaster_kt-link.cfg',
                    '-f', '../scripts/board/stm32nocca.cfg',
                    '-f', '../scripts/board/VCB_flash.cfg'
                ]

                result = subprocess.run(openocd_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

                # Check if the command was successful or not
                if result.returncode == 0:
                    logger.log_success(self.name,"------OpenOCD command executed successfully-----")
                    logger.log_info(self.name,"======================= VCB Update End ====================")
                    return True, None
                else:
                    # Handle the error based on the error messages in stderr
                    error_output = result.stderr
                    if "no device found" in error_output:
                        error_message = "no_device_found"
                        logger.log_error(self.name,f"{error_message}")
                        
                    elif "unable to open ftdi device" in error_output:
                        error_message = "unable_to_open_ftdi"
                        logger.log_error(self.name,f"{error_message}")
                        
                    elif "timeout waiting for algorithm"  in error_output:  
                        # retry Flashing Firmware  
                        logger.log_error(self.name,"Error: retry flashing for 2nd time...")  
                        
                        if(iRetry_count<2):
                            iRetry_count = iRetry_count +1 # 0 , 1
                            logger.log_info(self.name,"-------- Reflashing the firmware, Retry count: {} ---------".format(iRetry_count))
                            time.sleep(DELAY_BETWEEN_TWO_FIRMWARE_FLASH) 
                            return self.flash_firmware(iRetry_count) 
                        else:
                            error_message = "timeout_waiting_for_algorithm"
                            logger.log_error(self.name,f"{error_message}") 
                                                                                                                                                                                                                                                          
                    elif "JTAG scan chain interrogation failed" in error_output:
                        error_message = "JTAG_connection_failed"                                                                                                                                       
                        logger.log_error(self.name,f"{error_message}") 
                        
                    elif "checksum mismatch" in error_output:
                        error_message = "firmware_files_corrupted"
                        logger.log_error(self.name,f"{error_message}")
                        
                    else:
                        # Handle other errors
                        logger.log_error(self.name,f"{error_output}")

                    return False , error_message
                   
        except subprocess.CalledProcessError as e:
            error_message = f"Firmware flashing failed error: {e}"
            return False , error_message

        except Exception as e:
            error_message = f"Error occurred during flashing. {e}"
            return False, error_message
    
    # ------------------------------ Rollback Functionalities --------------------------------------

    def rollback_OS(self,stmOs_filesPath):
        """
        Description: This function will initate os rollback by running the "Install.sh" script.
                     return True if successfully run OS Script.
                     return False if not able to run OS Script. [then it cannot rollback OS : ---> FATAL FAILURE]
        """
        bReturnValue = False
        install_filePath = os.path.join(stmOs_filesPath,"Install.sh")
        if(os.path.exists(install_filePath)):
            script_file = "Install.sh"
            # scriptPath
            run_script_path = os.path.join(stmOs_filesPath,script_file)
            # change the permision
            os.chmod(run_script_path, 0o777)
            # run_script_path = f"source {run_script_path} -d && start_update"
            # bash_command = "source {0} -d && rollback_update"
            bash_command = "bash {0} -d && rollback_update"
            logger.log_info(self.name,f"bash command : {bash_command}")
            try:
                                    response = os.system(bash_command)
                                    responseCode = int(response)//256
                                    if(responseCode==0):
                                        bReturnValue = True
                                        logger.log_success(self.name,"======================= Bash script executed successfully. Response: " + str(responseCode) + " ===================")
                                    else:
                                        logger.log_error(self.name,"Not able to update Stm Os . ")
                                        bReturnValue = False
            except Exception as e:
                logger.log_error(self.name,f"Not able to Run Bash script: {e}")
                return bReturnValue
        else:
            logger.log_error(self.name,"----- Install.sh does not exist-----")
            return bReturnValue
        return bReturnValue
    
    def install_OS(self,stmOs_filesPath,stmOs_dependentPath,stmOs_dependentList):
            """
            Description: This function install the OS update by executing "Install.sh"
                         return True if  os is updated successfully
                         return False if os is not updated successfully
            """
            try: 
                    #------------------- extract all the OS_x.y.z.zip files  ---------------------
                    file_list = os.listdir(stmOs_dependentPath)
                    zip_files = [filename for filename in file_list if filename.endswith('.zip')]
                    for zip_file in zip_files:
                        zip_filepath = os.path.join(stmOs_dependentPath, zip_file)
                        shutil.unpack_archive(zip_filepath, stmOs_dependentPath)

                    # install file 
                    install_filePath = os.path.join(stmOs_filesPath,"Install.sh")
                
                    # check install file is present or not
                    if(os.path.exists(install_filePath)):
                                script_file = "Install.sh"
                                # scriptPath
                                run_script_path = os.path.join(stmOs_filesPath,script_file) #/usr/local/
                                # change the permision
                                os.chmod(run_script_path, 0o777)
                                # run_script_path = f"source {run_script_path} -d && start_update"
                                # bash_command = "source {0} -d && start_update {1}".format(run_script_path,' '.join([f'\'{item}\'' for item in stmOs_dependentList]))
                                bash_command = "bash {0} -d start_update {1}".format(run_script_path,' '.join([f'\'{item}\'' for item in stmOs_dependentList]))
                                logger.log_info(self.name,f"bash command : {bash_command}")
                                try:
                                    response = os.system(bash_command)
                                    responseCode = int(response)//256
                                    if(responseCode==0):
                                        bReturnValue = True
                                        logger.log_success(self.name,"======================= Bash script executed successfully. Response: " + str(responseCode) + " ===================")
                                    else:
                                        logger.log_error(self.name,"Not able to update Stm Os . ")
                                        bReturnValue = False
                                except Exception as e:
                                    logger.log_error(self.name,f"Not able to Run Bash script: {e}")
                                    return bReturnValue
                    else:
                        logger.log_error(self.name,"----- Install.sh does not exist-----")
                        return bReturnValue

            except Exception as e:
                logger.log_error(self.name,f"Error: {e}")
            
            return bReturnValue

    def install_py(self,stmOs_filesPath,stmOs_appPath,osVersion):
        """
        Description : This function install the STM PY update.
                      return True if successfully able to replace current FOTA_STM with new FOTA_STM
        """
        bReturnValue = False
        try:
            # extracting files 
            logger.log_info(self.name,"----Extracting files-----")
            for item in os.listdir(stmOs_appPath):
                item_path = os.path.join(stmOs_appPath, item)
                # Extract the contents of the directory
                if self.checkZIP(item_path):
                    # dont use  shutil.unpack_archive
                    if self.extractZIP(item_path,stmOs_appPath):
                        logger.log_info(self.name,f"-----{item_path} extracted successfully")
                    else:
                        logger.log_error(self.name,f"-----{item_path} not extracted .")
                        return False
                # You may want to delete the original archive file here if needed
                os.remove(item_path)

            logger.log_info(self.name,"----Extracted files successfully.-----")

            # check "File extracted or not "
            logger.log_info(self.name,"----- checking new FOTA_STM dir.... ")
            if(os.path.exists(os.path.join(stmOs_appPath,"FOTA_STM"))):
                logger.log_info(self.name,"----- FOTA_STM dir present . -----")

                script_file = "Install.sh"
                # scriptPath
                run_script_path = os.path.join(stmOs_filesPath,script_file)
                # change the permision
                os.chmod(run_script_path, 0o777)
                # run_script_path = f"source {run_script_path} -d && start_update"
                # bash_command = "source {0} -d && fota_update {1}".format(run_script_path,osVersion)
                bash_command = "bash {0} -d fota_update {1}".format(run_script_path,osVersion)
                logger.log_info(self.name,f"bash command : {bash_command}")
                try:
                        response = os.system(bash_command)
                        responseCode = int(response)//256
                        if(responseCode==0):
                            bReturnValue = True
                            logger.log_success(self.name,"======================= Bash script executed successfully. Response: " + str(responseCode) + " ===================")
                        else:
                            logger.log_error(self.name,"Not able to update Stm Os . ")
                            bReturnValue = False

                except Exception as e:
                    logger.log_error(self.name,f"Not able to Run Bash script: {e}")
                    return bReturnValue
            else:
                logger.log_error(self.name,"FOTA_STM dir not found.")
        except Exception as e:
            logger.log_error(self.name,"Exception error: {0}".format(e))
        return bReturnValue

    def copyStmUpdate(self,dJSONMsg):
        bReturnStatus = False
        try:
            basePath = "/usr/local/FOTA_STM_FILES"
            name = dJSONMsg[DATA_KEY]["update_pkg"]
            version = dJSONMsg["data"]["osVersion"]
                    
            stmObj = name["stmOs"]

            # stmOs is present that means update is there for stmOS 
            # copyfiles from download dir to actual 
            # and then installStm()
            
            logger.log_info(self.name,"=============> start copying stmOS pckges.... <==============")

            if(not os.path.exists(basePath)):
                os.makedirs(basePath,exist_ok=True)
            
            # ---------------create scp args 
            osSCPArgs , appSCPArgs, install_file_SCPArgs = self.createStmSCPArgs(stmObj)
                    
            stmOSDependencyDirPath = os.path.join(basePath, str("FOTA_STM_OSDEPENDENCY"))
            appPath = os.path.join(basePath,version)

            if(osSCPArgs!=""):
                        try:
                            if not os.path.exists(stmOSDependencyDirPath):
                                os.makedirs(stmOSDependencyDirPath,exist_ok=True)
                            logger.log_info(self.name,"Running SCP command-------------------------")
                            subprocess.run(["scp",osSCPArgs,stmOSDependencyDirPath])
                            logger.log_info(self.name,"SCP command succeeded")
                            bReturnStatus = True
                             
                        except Exception as e:
                            logger.log_error(self.name,f"Error running SCP command : {e}")
                            return bReturnStatus
            
            if(install_file_SCPArgs!=""):
                try:
                    logger.log_info(self.name,"Running SCP command-------------------------")
                    subprocess.run(["scp",install_file_SCPArgs,basePath])
                    logger.log_info(self.name,"SCP command succeeded")
                    bReturnStatus = True       
                except Exception as e:
                    logger.log_error(self.name,f"Error running SCP command : {e}")
                    return bReturnStatus

            if(appSCPArgs!=""):
                        try:
                            if not os.path.exists(appPath):
                                os.makedirs(appPath,exist_ok=True)
                            logger.log_info(self.name,"Running SCP command------------------------")
                            subprocess.run(["scp",appSCPArgs,appPath])
                            logger.log_info(self.name,"SCP command succeeded")
                            bReturnStatus = True
                        except Exception as e:
                            logger.log_error(self.name,f"Error running SCP command : {e}")
                            return bReturnStatus

        except Exception as e:
            logger.log_error(self.name,f"error : something went wrong during copying stm files: {e}")
            return bReturnStatus
        
        return bReturnStatus

    def installStm(self, dJSONMsg):
        # --------------- intialise variables ---------
        basePath = "/usr/local" # root path 
        stm_os_updateStatus = False
        stm_py_updateStatus = False 
        bReturnValue = False

        # ----------------- filter dJSONMsg ----------------
        data = dJSONMsg["data"]
        stmOs_pkg = data["update_pkg"]["stmOs"]
        osVersion = data["osVersion"]
        stmOs_klist = stmOs_pkg["files"]["stmOsGlbKList"] # can be empty also []
        os_file_list = stmOs_pkg["files"]["osFiles"] # can be empty also []
    

        # --------------- initialise paths ----------------
        stmOs_filesPath = os.path.join(basePath,"FOTA_STM_FILES")  # /usr/local/FOTA_STM_FILES
        stmOs_dependentPath = os.path.join(stmOs_filesPath,"FOTA_STM_OSDEPENDENCY")  # /usr/local/FOTA_STM_FILES/FOTA_STM_OSDEPENDENCY
        stmOs_appPath = os.path.join(stmOs_filesPath,str(osVersion)) # /usr/local/FOTA_STM_FILES/<x.y.z>

        logger.log_info(self.name,"---------- checking which file to update....  ")

        if(len(os_file_list) != 0):

            logger.log_info(self.name," -------- OS Update is present. -----------")
            os_file_list.sort()
            install_file = os_file_list[0] # Install_1.2.3.zip
            os_file = os_file_list[1] # OS_1.2.3.zip

            install_zipfile = os.path.join(stmOs_filesPath,str(install_file))

            # check this file is there or not 
            if(os.path.exists(install_zipfile)):

                try:
                    # Extract the ZIP file
                    logger.log_info(self.name,f"------------Extracting {install_zipfile} file.... ")
                    shutil.unpack_archive(install_zipfile, stmOs_filesPath)
                    logger.log_info(self.name,f"-------- file : {install_zipfile} extracted sucessfully.")
                    
                    # rename
                    if os.path.exists(os.path.join(stmOs_filesPath, "Install.sh")):

                        # if the file exists, then first delete the old file
                        logger.log_info(self.name,"---------- Removing old install file......")
                        os.remove(os.path.join(stmOs_filesPath, "Install.sh"))
                        logger.log_info(self.name,"---------- Removed old install file successfully.")

                    # then rename new file to "Install.sh"
                    logger.log_info(self.name,"-------- Renaming new Install file......")
                    install_shFile = install_zipfile.split(".zip")[0] + ".sh"
                    sh_file_path = os.path.join(stmOs_filesPath, install_shFile)
                    new_sh_file_path = os.path.join(stmOs_filesPath,"Install.sh")
                    os.rename(sh_file_path, new_sh_file_path)
                    logger.log_info(self.name,"-------- successfully renamed install file.")

                    logger.log_info(self.name,"---deleting install zipFile ---")
                    os.remove(install_zipfile)
                    logger.log_info(self.name,"install zipFile successfully deleted")

                except Exception as e:
                    logger.log_error(self.name,f"Exception during installation : {e}")
            
        # cross check for "Install.sh"
        if(os.path.exists(os.path.join(stmOs_filesPath,"Install.sh"))):

            logger.log_info(self.name,"---- Cross Verifying done for : Install file exists. ---- ")

            # check for os update 
            if(len(os_file_list) != 0):
                if(os.path.exists(os.path.join(stmOs_dependentPath,str(os_file_list[1])))):
                    # means stmOs_os update is present
                    stm_os_updateStatus = True
                    logger.log_info(self.name,"------ stm : os update is present. ----")

            # check for py update 
            if(os.path.exists(stmOs_appPath) and os.listdir(stmOs_appPath)):
                # means stmOs_py update is present 
                stm_py_updateStatus = True
                logger.log_info(self.name,"------ stm : py update is present. ----")

            # both
            if(stm_os_updateStatus and stm_py_updateStatus):
                logger.log_info(self.name,"------ Both stm: os and stm:py updates are present. ----")
                # run :  install_os
                logger.log_info(self.name,"------ installing stm : os .... ")
                if(self.install_OS(stmOs_filesPath,stmOs_dependentPath,stmOs_klist)):
                    logger.log_success(self.name,"------ successfully installed stm : os update. ")

                    logger.log_info(self.name,"------ Now, installing stm : py ..... ")

                    # run : install_py
                    if(self.install_py(stmOs_filesPath,stmOs_appPath,osVersion)):
                        bReturnValue = True
                        logger.log_success(self.name,"------ successfully installed stm: py update. ")
                        logger.log_success(self.name,"------ Finally, successfully updated both stm: py and stm :os . ")
                    else:
                        logger.log_error(self.name,"------ Not able to install FOTA_STM_PY file ")
                        logger.log_info(self.name,"------ starting OS rollback .... ")
                        if(self.rollback_OS(stmOs_filesPath)):
                            logger.log_info(self.name,"----- OS rollBack successfull.")
                        else:
                            logger.log_error(self.name,"------ Not able to Perform OS rollback.")
                else:
                    logger.log_error(self.name,"--- Not able to install FOTA_STM_OS file ")
            # only os update
            elif(stm_os_updateStatus):

                logger.log_info(self.name,"------ Only stm: os update are present. ----")
                logger.log_info(self.name,"------ installing stm : os .... ")
                # run : install_os
                if(self.install_OS(stmOs_filesPath,stmOs_dependentPath,stmOs_klist)):
                    bReturnValue = True
                    logger.log_success(self.name,"------ successfully installed stm : os update. ")
                else:
                    logger.log_error(self.name,"--- Not able to install FOTA_STM_OS file. -------")
            # only py update 
            elif(stm_py_updateStatus):
                logger.log_info(self.name,"------ Only stm: py update are present. ----")
                # run : install_py
                if(self.install_py(stmOs_filesPath,stmOs_appPath,osVersion)):
                    bReturnValue = True
                    logger.log_success(self.name,"------ successfully installed stm: py update. ")
                else:
                    logger.log_error(self.name,"--- Not able to install FOTA_STM_PY file -------")

            # remove dir
            if(os.path.exists(stmOs_filesPath)):
                if(os.path.exists(stmOs_dependentPath)):
                    shutil.rmtree(stmOs_dependentPath)
                if(os.path.exists(stmOs_appPath)):
                    shutil.rmtree(stmOs_appPath)
        else:
            logger.log_error(self.name,"--- Not able to install as install file does not exist.-----")       
        return bReturnValue

    def checkSoftwareUpdate(self,dJSONMsg):
        """
        Description: This function checks which software Update is present .It can be either software(consists of BACKEND , UI ) or firmware (MASTER , SLAVE)
        
        """
        bReturnStatus = False
        basePath = "/usr/local/zmq/FOTA_STM"
        try:
            logger.log_info(self.name,f"=====>>>  Inside checkSoftwareUpdate function ... <<<====")

            # from update_type extract 
            name = dJSONMsg[DATA_KEY]["update_pkg"] # [TODO]  name --> will be later renamed to package_present 
            
            # firmware
            if name.get("firmware")!=None:
                logger.log_info(self.name," ======> Firmware update is present. <====== ")
                logger.log_info(self.name," ======> start copying firmware pckges from iomt to stm... <====== ")

                fwObj = name["firmware"]
                fwSCPArgs = self.createSCPArgs(fwObj)
                fwFileList =  fwObj["files"] # Master_x.y.z.zip  , Slave_x.y.z.zip
                
                # fwOTADirPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), str("Firmware"))
                fwOTADirPath = os.path.join(basePath,str("Firmware"))

                if not os.path.exists(fwOTADirPath):
                    os.makedirs(fwOTADirPath,exist_ok=True)

                if(fwSCPArgs!=""):
                    try:
                        logger.log_info(self.name,"----------- Running SCP command for copying firmware files....")
                        subprocess.run(["scp",fwSCPArgs,fwOTADirPath])
                        logger.log_info(self.name,"----------- SCP command succeeded for firmware files.")
                    except Exception as e:
                        logger.log_error(self.name,f"Error running SCP command : {e}" )
                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                        return bReturnStatus

                    if(True == os.path.exists(fwOTADirPath)):
                            fwMapping = {}

                            for strPkgName in fwFileList: 
                                zipFilePath = os.path.join(fwOTADirPath,strPkgName) # zip File 
                                if(self.checkZIP(zipFilePath)):
                                    logger.log_info(self.name,f"---------------- Extracting pckg {strPkgName}....")
                                    if(self.extractZIP(zipFilePath,fwOTADirPath)):
                                        logger.log_info(self.name,f"------------ Successfully extracted {strPkgName} !!")
                                        hexFileName = strPkgName.split(".zip")[0]+".hex"
                                        newStrPckgName = strPkgName.split("_")[0]+".hex"
                                        fwMapping[hexFileName] = newStrPckgName
                                    else:
                                        logger.log_error(self.name,"Unable to extract File.")
                                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                                        return bReturnStatus
                                else:
                                    logger.log_error(self.name,"File is not zip file.")
                                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                                    return bReturnStatus

                            if(self.changeFileName(fwMapping,fwOTADirPath)):
                                logger.log_info(self.name,"--------- Successfully Renamed Files.")
                                if(self.checkFiles(fw_pkg_files_location)):
                                    bReturnStatus = True
                                else:
                                    logger.log_error(self.name,"File check failed.")
                                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                                    return bReturnStatus
                            else:
                                logger.log_error(self.name,"Not able to rename files.") 
                                self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                                return bReturnStatus                  
                    else:
                        logger.log_error(self.name,"Copied file not exists, Something went wrong.") 
                        self.sendError(dJSONMsg,BACKEND_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)    
                        return bReturnStatus      
                else:
                    logger.log_error(self.name,"Invalid scp command.")
                    self.sendError(dJSONMsg,BACKEND_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                    return bReturnStatus

            # software
            if name.get("software")!=None:
                logger.log_info(self.name," ======> software update is present. <====== ")
                logger.log_info(self.name," ======> start copying software pckges from iomt to stm... <====== ")
            
                swObj = name["software"]
                swSCPArgs = self.createSCPArgs(swObj)
                swFileList = swObj["files"]
                swFileList = sorted(swFileList)

                # swOTADirPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), str("Software"))
                swOTADirPath = os.path.join(basePath,str("Software"))
                if not os.path.exists(swOTADirPath):
                    os.makedirs(swOTADirPath)

                # run the scp 
                if(swSCPArgs!=""):
                    try:
                        logger.log_info(self.name,"----------- Running SCP command for copying software files....")
                        subprocess.run(["scp",swSCPArgs,swOTADirPath])
                        logger.log_info(self.name,"----------- SCP command succeeded for software files.")
                    except Exception as e:
                        logger.log_error(self.name,f"Error running SCP command : {e}")
                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                        return bReturnStatus

                    if(True == os.path.exists(swOTADirPath)):
                        
                            for strPkgName in swFileList: 

                                zipFilePath = os.path.join(swOTADirPath,strPkgName) 

                                if(self.checkZIP(zipFilePath)):

                                    logger.log_info(self.name,f"---------------- Extracting pckg {strPkgName}....")

                                    if(self.extractZIP(zipFilePath,swOTADirPath)):
                                        logger.log_info(self.name,f"------------ Successfully extracted {strPkgName} !!")
                                    else:
                                        logger.log_error(self.name,"Unable to extract file")
                                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                                        return bReturnStatus
                                else:
                                    logger.log_error(self.name,"File is not zip file ")
                                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                                    return bReturnStatus
                                
                            # check Files 
                            if(self.checkFiles(sw_pkg_files_location)):
                                    bReturnStatus = True
                            else:
                                logger.log_error(self.name,"File check Failed.")
                                self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                                return bReturnStatus
                    else:
                        logger.log_error(self.name,"Copied file not exists, Something went wrong")
                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
                        return bReturnStatus
                else:
                    logger.log_error(self.name,"Invalid scp command")
                    return bReturnStatus

            # Final check - all the software or firmware files are present in the respective directory or not
            # if name.get("firmware") != None or name.get("software")!=None:      
            #     for key in ota_pkg_files_locaiton:
            #             newPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), str(""))
            #             path = os.path.join(newPath,ota_pkg_files_locaiton[key])
            #             if(True != os.path.exists(os.path.join(newPath,ota_pkg_files_locaiton[key]))):
            #                     logger.log_error(self.name,"{0} is not available in OTA package".format(key))
            #                     bReturnStatus = False
            #                     return bReturnStatus
            #             else:
            #                     bReturnStatus = True

        except Exception as e:
            logger.log_error(self.name,"Failed to check key exists in dictonary: {0} error: {1}".format(dJSONMsg,e))
            logger.log_error(self.name,traceback.format_exc())
            # self.sendError(dJSONMsg,BACKEND_DEALER_ID,ERROR_CODE_PKG_DOWNLOAD_FAILED)
            return bReturnStatus

        return bReturnStatus

    def installSoftware(self,dJSONMsg):
        logger.log_info(self.name,"=========> Installing Software Packages...... <========")
        bReturnValue = False
        try:
            basePath = "/usr/local"
            strSourcePath = ""
            strDestinationPath = ""
            newfirmwareUpdateStatus = False
            newSoftwareUpdateStatus = False
            stmOsUpdateStatus = False
            data = dJSONMsg["data"]
            pckgName = data["update_pkg"]
            strOTADirPath = os.path.join(str("/usr/local/zmq/FOTA_STM"), str("")) # /usr/local/zmq/FOTA_STM/

            # ----- 
            fwOTADirPath = os.path.join(strOTADirPath,str("Firmware")) # /usr/local/zmq/FOTA_STM/Firmware
            swOTADirPath = os.path.join(strOTADirPath,str("Software")) # /usr/local/zmq/FOTA_STM/Software
            stmOsDirPath = os.path.join(basePath,str("FOTA_STM_FILES")) # /usr/local/FOTA_STM_FILES

            # checkUpdateStatus - which update is present 
            if(self.checkUpdateStatus(fwOTADirPath)):
                newfirmwareUpdateStatus = True
                logger.log_warning(self.name,"---------- firmware update present.")
            else:
                logger.log_warning(self.name,"---------- firmware update is not present.")
            if(self.checkUpdateStatus(swOTADirPath)):
                newSoftwareUpdateStatus = True
                logger.log_warning(self.name,"---------- software update present.")
            else:
                logger.log_warning(self.name,"---------- software update is not present.")
            
            # case 1: when both update are present 
            if(newSoftwareUpdateStatus and newfirmwareUpdateStatus):
                logger.log_info(self.name,"----------------- software and firmware both updates are present.")
                # copy : sw Files 
                logger.log_info(self.name,"-------------- starting software files installation process...")
                swTransferStatus = self.copySWFiles(strOTADirPath)

                if(swTransferStatus ==True):
    
                    logger.log_success(self.name,"----------- software files installed successfully.")

                    logger.log_info(self.name,"-------------- starting firmware files installation.....")

                    logger.log_info(self.name,"-------------- verifying firmware connection with Hardware....")

                    if(True==self.verfiy_firmware()):

                        logger.log_info(self.name,"-------------firmware connection with hardware verified successfully.")

                        logger.log_info(self.name,"-------------- starting copying firmware files ....")

                        # copy: fw Files
                        fwTransferStatus = self.copyFWFiles(strOTADirPath)

                        if(fwTransferStatus ==True):

                            logger.log_info(self.name,"-------------- firmware files successfully copied.")

                            logger.log_info(self.name,"-------------- starting firmware flashing....")
                            # flash firmware 
                            firmware_flash_status, error_message = self.flash_firmware(0)
                            if(firmware_flash_status):
                                logger.log_info(self.name,"-------------- firmware flashed successfully.")
                                logger.log_success(self.name,"----------- firmware files installed successfully.")
                                # reset firmware 
                                self.reset_firmware()
                                logger.log_success(self.name,"----------------- Finally, Both Software and Firmware Versions Updated Successfully.")
                                bReturnValue = True
                            else:
                                logger.log_error(self.name,f"Unable to able Flash Firmware. Error: {error_message} ")
                                logger.log_error(self.name,"--------------> Backup starts.... <----------")
                                self.useOldFWFiles()
                                self.useOldSWFiles()
                                logger.log_error(self.name,"------------> Backup completed. <------------")
                                error_code = FIRMWARE_ERROR_MAPPING.get(error_message.lower(), None)
                                if error_code is not None:
                                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,error_code)
                                else:
                                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,FIRMWARE_INTERNAL_ERROR)
                                # return bReturnValue
                        else:
                            logger.log_error(self.name,"----- Not able to copy Firmware Files.")
                            logger.log_error(self.name,"------------>>> Backup starts.... <<<--------")
                            self.useOldFWFiles()
                            self.useOldSWFiles()
                            logger.log_error(self.name,"---------->>> Backup completed. <<<---------")
                            self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,FIRMWARE_INTERNAL_ERROR)
                            # return bReturnValue
                            
                    else:
                        logger.log_error(self.name,"-----  Unable to verfiy Firmware.")
                        logger.log_error(self.name,"------------>>> Backup starts.... <<<--------")
                        self.useOldSWFiles()
                        logger.log_error(self.name,"---------->>> Backup completed. <<<---------")
                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,FIRMWARE_VERIFICATION_ERROR)
                        # return bReturnValue
                        
                else:
                    logger.log_error(self.name,"Not able to copy Software Files.")
                    logger.log_error(self.name,"------------>>> Backup starts....<<<--------")
                    self.useOldSWFiles()
                    logger.log_error(self.name,"------------>>> Backup completed.<<<--------")
                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,SOFTWARE_INTERNAL_ERROR)
                    # return bReturnValue
                    
            # case 2: only software update present 
            elif(newSoftwareUpdateStatus):
                logger.log_info(self.name,"----------------- only software update is present.")
                logger.log_info(self.name,"-------------- starting software files installation process...")

                swTransferStatus = self.copySWFiles(strOTADirPath)
                if(swTransferStatus==True):

                    logger.log_success(self.name,"----------- software files installed successfully.")
                    logger.log_info(self.name,"-------------- starting firmware files installation.....")
                    logger.log_info(self.name,"-------------- verifying firmware connection with Hardware....")
                    if(True==self.verfiy_firmware()):
                            logger.log_info(self.name,"------------- firmware connection with Hardware verified successfully.")
                            self.reset_firmware()
                            logger.log_success(self.name,"----------- Software Version Updated Successfully!!!")
                            bReturnValue = True
                    else:
                        logger.log_error(self.name,"Unable to verfiy Firmware during software installation process.")
                        logger.log_error(self.name,"------------>>> Backup starts.... <<<--------")
                        self.useOldSWFiles()
                        logger.log_error(self.name,"---------->>> Backup completed. <<<---------")
                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,FIRMWARE_VERIFICATION_ERROR)
                        # return bReturnValue
                else:
                    logger.log_error(self.name,"Not able to copy Software Files.")
                    logger.log_error(self.name,"------------>>> Backup starts.... <<<--------")
                    self.useOldSWFiles()
                    logger.log_error(self.name,"---------->>> Backup completed. <<<---------")
                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,SOFTWARE_INTERNAL_ERROR)
                    # return bReturnValue
                    
            # case 3: only firmware update present
            elif(newfirmwareUpdateStatus):
                logger.log_info(self.name,f"----------only Firmware Update is present.")
                logger.log_info(self.name,"-------------- verifying firmware connection with Hardware....")
                if(True==self.verfiy_firmware()):
                    
                    logger.log_info(self.name,"------------- firmware connection with Hardware verified successfully.")
                    logger.log_info(self.name,"-------------- starting copying firmware files ....")

                    fwTransferStatus = self.copyFWFiles(strOTADirPath)

                    if(fwTransferStatus==True):
                        logger.log_info(self.name,"-------------- firmware files successfully copied.")

                        logger.log_info(self.name,"-------------- starting firmware flashing....")

                        firmware_flash_status, error_message = self.flash_firmware(0)

                        if(firmware_flash_status):
                            logger.log_info(self.name,"-------------- firmware flashed successfully.")
                            self.reset_firmware()
                            logger.log_success(self.name,"------------ Firmware Version Updated Successfully!!!")
                            bReturnValue = True
                        else:
                            logger.log_error(self.name,"Unable to Flash Firmware during Firmware Installation Process.")
                            logger.log_error(self.name,"------------>>> Backup starts.... <<<--------")
                            self.useOldFWFiles()
                            logger.log_error(self.name,"---------->>> Backup completed. <<<---------")
                            error_code = FIRMWARE_ERROR_MAPPING.get(error_message.lower(), None)
                            if error_code is not None:
                                self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,error_code)
                            else:
                                self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,FIRMWARE_INTERNAL_ERROR)   
                            # return bReturnValue
                            
                    else:
                        logger.log_error(self.name,"Not able to Copy Firmware Files.")
                        logger.log_error(self.name,"------------>>> Backup starts.... <<<--------")
                        self.useOldFWFiles()
                        logger.log_error(self.name,"---------->>> Backup completed. <<<---------")
                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,FIRMWARE_INTERNAL_ERROR)
                        # return bReturnValue
                else:
                    logger.log_error(self.name,"Unable to verfiy Firmware.")
                    logger.log_error(self.name,"------------>>> Backup starts.... <<<--------")
                    self.useOldFWFiles()
                    logger.log_error(self.name,"---------->>> Backup completed. <<<---------")
                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,FIRMWARE_VERIFICATION_ERROR)
                    # return bReturnValue
        
            # remove the unnecessary files 
            if(os.path.exists(swOTADirPath)):
                logger.log_info(self.name,f"=====>>> Removing software files from {swOTADirPath}.... <<<======")
                shutil.rmtree(swOTADirPath)
                logger.log_info(self.name,f"=====>>> Successfully , Removed software files from {swOTADirPath}.... <<<======")
            else:
                logger.log_warning(self.name,f"---- software pckg dir does not exist in path {swOTADirPath}.")

            if(os.path.exists(fwOTADirPath)):
                logger.log_info(self.name,f"=====>>>> Removing firmware files from {fwOTADirPath}... <<<======")
                shutil.rmtree(fwOTADirPath)
                logger.log_info(self.name,f"=====>>>> Successfully , Removed firmware files from {fwOTADirPath}.  <<<======")
            else:
                logger.log_warning(self.name,f"---- Firmware pckg dir does not exist in path {fwOTADirPath}")

        except Exception as e:
            logger.log_error(self.name,"Failed to check key exists in dictonary: {0} error: {1}".format(dJSONMsg,e))
            logger.log_error(self.name,traceback.format_exc())
            self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_CODE_FAILED_TO_INSTALL_PKG)
            return bReturnValue
        return bReturnValue        

    def sendInValidJSONMessage(self, dJSONMsg, iDestinationDealerId, iMessageType):
        # ---------------------------- TODO ------------------------------
        # iMsgType = 0
        # if(iMessageType == MSG_TYPE_PKG_DOWNLOADED):
        #     if self.keys_exists(dJSONMsg,DATA_KEY,PKG_TYPE_KEY):
        #         if dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_UPGRADE:
        #             iMsgType = MSG_TYPE_PKG_UPGRADE
        #         elif dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_ROLLBACK:
        #             iMsgType = MSG_TYPE_PKG_ROLLBACK
        #     else:
        #         iMsgType = MSG_TYPE_PKG_DOWNLOADED
        # else:
        #     iMsgType = iMessageType

        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
        dJSONMsg[DESTINATION_KEY] = iDestinationDealerId
        dJSONMsg[MESSAGE_TYPE_KEY] = iMessageType
        dJSONMsg["task_type"] = "response"
        dJSONMsg[STATUS_KEY] = ERROR_CODE_INVALID_JSON
        dJSONMsg[DATA_KEY] = {}
        self.send_data(dJSONMsg)

    # ------ send Error ------
    def sendError(self,dJSONMsg,iDestinationDealerId, errorCode):
        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
        dJSONMsg[DESTINATION_KEY] = iDestinationDealerId
        dJSONMsg[STATUS_KEY] = errorCode
        dJSONMsg["task_type"] = "response"
        dJSONMsg[DATA_KEY] = {}
        self.send_data(dJSONMsg)

    # --- -- set progress ----
    def setProgress(self,dJSONMsg, task):
        progressValue = 0 
        if(task == MSG_TYPE_PKG_UPGRADE_OS):
            # case: iomt and stm 
            if((dJSONMsg["data"]["update_type"].get("stmOs")==1) and (dJSONMsg["data"]["update_type"].get("iomtOs")==1)):
                progressValue = progressValue + 40
            else:
                progressValue = progressValue + 80

            dJSONMsg["data"]["progress"] += progressValue
            
        elif(task == MSG_TYPE_PKG_UPGRADE_SOFTWARE):
            # check whether already iomtOs or stmOs was present or not 
            if((dJSONMsg["data"]["update_type"].get("stmOs")==1) and (dJSONMsg["data"]["update_type"].get("iomtOs")==1)):
                progressValue = progressValue + 50
            else:
                progressValue = progressValue + 80
            dJSONMsg["data"]["progress"] += progressValue
        
        elif(task == MSG_TYPE_PKG_UPGRADE_BOTH_SOFTWARE_OS):
            # for os both are present 
            if((dJSONMsg["data"]["update_type"].get("stmOs")==1) and (dJSONMsg["data"]["update_type"].get("iomtOs")==1)):
                progressValue = progressValue + 15
            else: 
                progressValue = progressValue + 30
            
            dJSONMsg["data"]["progress"] += progressValue
        return dJSONMsg

    def parseZmqRouterRequest(self, dJSONMsg):

        if self.keys_exists(dJSONMsg, MESSAGE_TYPE_KEY):

            """
                type: 2 (heartbeat)
                desc: heartbeat mssg to check whether stm is alive or not request
            """
            if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_HEART_BEAT:
                dJSONMsg.clear()
                # modify the queuepacket and send response 
                dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                dJSONMsg[DESTINATION_KEY] = ROUTER_ID
                dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_HEART_BEAT
                dJSONMsg[STATUS_KEY] = SUCCESS
                dJSONMsg[DATA_KEY] = {}
                self.send_data(dJSONMsg)

            
            # if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_UPGRADE or dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_ROLLBACK:
                                
            #     if (self.keys_exists(dJSONMsg,DATA_KEY,"status")) :
            #         # softwareVersion = str(dJSONMsg[DATA_KEY][PKG_SW_VERSION_KEY])
            #         # osVersion = str(dJSONMsg[DATA_KEY][PKG_OS_VERSION_KEY])
            #         # iMsgType = dJSONMsg[MESSAGE_TYPE_KEY]
            #         # dJSONMsg.clear()
            #         # dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
            #         # dJSONMsg[DESTINATION_KEY] = FOTA_IOMT_DEALER_ID
            #         # dJSONMsg[MESSAGE_TYPE_KEY] = iMsgType
            #         # dJSONMsg[DATA_KEY] = {"softwareVersion":softwareVersion,"osVersion":osVersion}
            #         self.send_data(dJSONMsg)
            #     else:
            #         logger.log_error(self.name,"verison keys is not avaialble in received JSON message: {0}".format(dJSONMsg))
            #         self.sendInValidJSONMessage(dJSONMsg,BACKEND_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])


            """
                type: 50 ( os update ) , 52 ( both os and software)
                desc:
            """
            if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_UPGRADE_OS  or dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_UPGRADE_BOTH_SOFTWARE_OS :
                
                # check status key 
                if (self.keys_exists(dJSONMsg,STATUS_KEY)) and (dJSONMsg[STATUS_KEY] == SUCCESS):

                    logger.log_info(self.name,"------ Verfiying Keys .... ------")
                   
                    # TODO : Key exists for "stmOs"
                    if (self.keys_exists(dJSONMsg,DATA_KEY,PKG_OS_VERSION_KEY)) and (self.keys_exists(dJSONMsg,DATA_KEY,PKG_UPDATEPKG_KEY)) and (self.keys_exists(dJSONMsg,DATA_KEY,PKG_TYPE_KEY)):
                        logger.log_info(self.name,"--------- Keys Verification Done. ---------")
                        
                        
                        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                        dJSONMsg[DESTINATION_KEY] = FOTA_IOMT_DEALER_ID 
                        dJSONMsg["task_type"]= "response"
                       
                        if dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_UPGRADE: 

                            if(dJSONMsg["data"]["update_pkg"].get("stmOs")!=None and dJSONMsg["data"]["update_pkg"]["stmOs"]["stmUpdateStatus"]!=1):
                                
                                logger.log_info(self.name,f"----------  Copying Stm Pckges  ....  ---------")

                                # copy stm pckg 
                                stmOsUpdateStatus = self.copyStmUpdate(dJSONMsg)

                                if(stmOsUpdateStatus==True):
                                    
                                    logger.log_info(self.name,f"--------  Copied new Stm Pckges.  -------")

                                    logger.log_info(self.name,f"-------  Installing new STM pkges  ....  --------")

                                    if(self.installStm(dJSONMsg)==True):
                                        logger.log_info(self.name,f"-------  successfully Installed new STM pkges .  --------")
                                        dJSONMsg["data"]["update_pkg"]["stmOs"]["stmUpdateStatus"]  = SUCCESS
                                        dJSONMsg = self.setProgress(dJSONMsg,dJSONMsg[MESSAGE_TYPE_KEY]) # send progress
                                        logger.log_success(self.name,"---------- Successfully updated STMOS. ---------")
                                        #add delay
                                        time.sleep(3)
                                        self.send_data(dJSONMsg)
                                    else:
                                        logger.log_error(self.name,"Not able to update stmOS")
                                        self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_INSTALLING_STMOS)
                                else:
                                    logger.log_error(self.name,"Not able to copy stmOs files")
                                    self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,ERROR_INSTALLING_STMOS) 
                            else:
                                logger.log_info(self.name,"STMOS.Already up-to date.")
                                dJSONMsg["task_type"]= "response"
                                # dJSONMsg["data"]["update_pkg"]["stmOs"]["stmUpdateStatus"]  = SUCCESS
                                dJSONMsg = self.setProgress(dJSONMsg,dJSONMsg[MESSAGE_TYPE_KEY])
                                logger.log_success(self.name,"------- STMOS. Already up-to date. ---------")
                                #add delay
                                time.sleep(3)
                                self.send_data(dJSONMsg)        
                    else:
                        logger.log_error(self.name,"InSufficient keys in received JSON message: {0}".format(dJSONMsg))
                        self.sendInValidJSONMessage(dJSONMsg,FOTA_IOMT_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])
                else:
                    logger.log_error(self.name,"InValid keys in received JSON message: {0}".format(dJSONMsg))
                    self.sendInValidJSONMessage(dJSONMsg,FOTA_IOMT_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])
            
            """
                type: 51 (only software update present)
                desc:
            """
            if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_UPGRADE_SOFTWARE:
                
                logger.log_info(self.name,"------ Verfiying Keys .... ------")

                if (self.keys_exists(dJSONMsg,STATUS_KEY)) and (dJSONMsg[STATUS_KEY] == SUCCESS):
                    
                    if (self.keys_exists(dJSONMsg,DATA_KEY,PKG_SW_VERSION_KEY)) and (self.keys_exists(dJSONMsg,DATA_KEY,PKG_UPDATEPKG_KEY)) and ((self.keys_exists(dJSONMsg,DATA_KEY,PKG_TYPE_KEY))):
                        logger.log_info(self.name,"------ Key Verification Done. -----")
                        
                        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                        dJSONMsg[DESTINATION_KEY] = FOTA_IOMT_DEALER_ID 
                        dJSONMsg["task_type"]= "response"
                        swUpdatePresent  = False
                        fwUpdatePresent = False
                        
                        if dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_UPGRADE: 
                            
                            # check which update is present 
                            if(dJSONMsg["data"]["update_pkg"].get("software") is not None and dJSONMsg["data"]["update_type"].get("software") is not None):
                                swUpdatePresent = True
                            if(dJSONMsg["data"]["update_pkg"].get("firmware") is not None and dJSONMsg["data"]["update_type"].get("firmware") is not None):
                                fwUpdatePresent = True

                            if(self.checkSoftwareUpdate(dJSONMsg)==True):

                                logger.log_info(self.name,"----- start installing software pckges....... ---")

                                if(self.installSoftware(dJSONMsg)==True):

                                    logger.log_success(self.name,"-------- successfully installed software pckges ------")
                                    if(swUpdatePresent and fwUpdatePresent):
                                        dJSONMsg["data"]["update_pkg"]["software"]["softwareUpdateStatus"]=1 
                                        dJSONMsg["data"]["update_pkg"]["firmware"]["firmwareUpdateStatus"]=1 
                                        logger.log_success(self.name,"---------- software and firmware updated successfully")
                                    elif(swUpdatePresent):
                                        dJSONMsg["data"]["update_pkg"]["software"]["softwareUpdateStatus"]=1
                                        logger.log_success(self.name,"---------- software updated successfully.")
                                    elif(fwUpdatePresent):
                                        dJSONMsg["data"]["update_pkg"]["firmware"]["firmwareUpdateStatus"]=1 
                                        logger.log_success(self.name,"---------- firmware updated successfully")
                                    
                                    dJSONMsg = self.setProgress(dJSONMsg,dJSONMsg[MESSAGE_TYPE_KEY])
                                    #add delay
                                    time.sleep(3)

                                    self.send_data(dJSONMsg)
                                else:
                                    logger.log_error(self.name,"Not able to install software files.")
                                    # self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,SOFTWARE_INTERNAL_ERROR)   
                            else:
                                logger.log_error(self.name,"Not able to copy software files")
                                # self.sendError(dJSONMsg,FOTA_IOMT_DEALER_ID,SOFTWARE_INTERNAL_ERROR)                 

                    else:
                        logger.log_error(self.name,"InSufficient keys in received JSON message: {0}".format(dJSONMsg))
                        self.sendInValidJSONMessage(dJSONMsg,FOTA_IOMT_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY]) 
         
                else:
                    logger.log_error(self.name,"InValid keys in received JSON message: {0}".format(dJSONMsg))
                    self.sendInValidJSONMessage(dJSONMsg,FOTA_IOMT_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY]) 

            """
                type: 10 (rollback)
                desc:
            """
            if  dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_ROLLBACK_SOFTWARE:
                logger.log_info(self.name,"------ Verfiying Keys .... ------")

                if (self.keys_exists(dJSONMsg,STATUS_KEY)) and (dJSONMsg[STATUS_KEY] == SUCCESS):
                    
                    logger.log_info(self.name,"------ verifying software keys ---")
                    if (self.keys_exists(dJSONMsg,DATA_KEY,PKG_SW_VERSION_KEY)) and (self.keys_exists(dJSONMsg,DATA_KEY,PKG_UPDATEPKG_KEY)) and ((self.keys_exists(dJSONMsg,DATA_KEY,PKG_TYPE_KEY))):
                        logger.log_info(self.name,"------ Key Verification Done. -----")
                        
                        dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                        dJSONMsg[DESTINATION_KEY] = FOTA_IOMT_DEALER_ID 
                        dJSONMsg["task_type"]= "response"

                        # --- Initialise Variables ---
                        swRollbackPresent  = False
                        fwRollbackPresent = False
                        
                        logger.log_info(self.name,"------ Initiate Rollback SOFTWARE ....  --------")
                        if dJSONMsg[DATA_KEY][PKG_TYPE_KEY] == PACKAGE_TYPE_ROLLBACK: 
                            
                            logger.log_info(self.name,"---- checking which rollback is present ------")

                            # check which rollback is present 
                            if(dJSONMsg["data"]["update_pkg"].get("software") is not None and dJSONMsg["data"]["update_type"].get("software") is not None):
                                swRollbackPresent = True
                            if(dJSONMsg["data"]["update_pkg"].get("firmware") is not None and dJSONMsg["data"]["update_type"].get("firmware") is not None):
                                fwRollbackPresent = True

                          
                            if(self.checkSoftwareUpdate(dJSONMsg)==True):

                                logger.log_info(self.name,"----- starting rollback of software pckges....... -----")

                                if(self.installSoftware(dJSONMsg)==True):
                                    
                                    logger.log_success(self.name,"------ successfully installed rollback software pckges.  -----")
                                    dJSONMsg["task_type"]= "response"

                                    if(swRollbackPresent and fwRollbackPresent):
                                        dJSONMsg["data"]["update_pkg"]["software"]["softwareRollbackStatus"]=1 
                                        dJSONMsg["data"]["update_pkg"]["firmware"]["firmwareRollbackStatus"]=1 
                                        logger.log_success(self.name,"--------- ROLLBACK: software and firmware rollback successfully")
                                        #add delay
                                        time.sleep(3)
                                        self.send_data(dJSONMsg)
                                    elif(swRollbackPresent):
                                        dJSONMsg["data"]["update_pkg"]["software"]["softwareRollbackStatus"]=1
                                        logger.log_success(self.name,"--------- ROLLBACK: software rollback successfully.")
                                        #add delay
                                        time.sleep(3)
                                        self.send_data(dJSONMsg)
                                    elif(fwRollbackPresent):
                                        dJSONMsg["data"]["update_pkg"]["firmware"]["firmwareRollbackStatus"]=1 
                                        logger.log_success(self.name,"---------ROLLBACK: firmware rollback successfully")
                                        #add delay
                                        time.sleep(3)
                                        self.send_data(dJSONMsg)
                                else:
                                    logger.log_error(self.name,"Not able to rollback software files.")

                            else:
                                logger.log_error(self.name,"Not able to copy software rollback files")                          

                    else:
                        logger.log_error(self.name,"InSufficient keys in received JSON message: {0}".format(dJSONMsg))
                        self.sendInValidJSONMessage(dJSONMsg,BACKEND_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])
         
                else:
                    logger.log_error(self.name,"InValid keys in received JSON message: {0}".format(dJSONMsg))
                    self.sendInValidJSONMessage(dJSONMsg,FOTA_IOMT_DEALER_ID,dJSONMsg[MESSAGE_TYPE_KEY])

            """
                type: 16 (machineRegisteration)
                desc: start machine registeration request
                STATUS: COMPLETED
            """
            if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_ENTER_MACHINE_REGISTRATION:
                dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
                dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_ENTER_MACHINE_REGISTRATION
                dJSONMsg[STATUS_KEY] = SUCCESS
                dJSONMsg[DATA_KEY] = {}
                self.send_data(dJSONMsg)
                # start scanning 
                barcodeScannerObj.run()
            
        else:
            logger.log_error(self.name,"Message type key is not found in rcv packet: {0}".format(dJSONMsg))
            # Sending the Invalid JSON message, because we didn't get message type
            # cosidering the message type 0
            self.sendInValidJSONMessage(dJSONMsg,BACKEND_DEALER_ID,0)


    '''
    FLOW:
    copyStmUpdate() --> checks stmos update is present or not 
    if yes, then run installStmOs()
    yes or no , then send response to IOMT , [checkIomtUpdate(), yes -> installIomt() , yes or No -> send response back to stm. ]
    checkSoftwareUpdate() -> firmware or software , installSoftwareUpdate() 
    send response back to iomtOs
    '''
"""
                         {
                            'source': 4, 
                            'destination': 3, 
                            'type': 7, 
                            'status': 1, 
                            'data': 
                                { 
                                    'osVersion': '1.1.0', 
                                    'softwareVersion': '1.1.0', 
                                    'pkg_type': 1, 
                                    'update_type': { 'firmware': 1, 'software': 1, 'stmOs': 1, 'iomtOs': 1}, 
                                    'update_pkg': 
                                    {
                                    'firmware': 
                                    {
                                        // it will scp latest file only 
                                        'location': '/home/root/OTA/system_softwareVersion/firmware/1.1.0/*.zip', 
                                        'files': ['Master_1.1.0.zip', 'Slave_1.1.0.zip']
                                    }, 
                                    'software': 
                                    {
                                        // it will scp latest file only 
                                        'location': '/home/root/OTA/system_softwareVersion/software/1.1.0/*.zip', 
                                        'files': ['UI_1.1.0.zip', 'BE_1.1.0.zip']
                                    }, 
                                    'stmOs': 
                                    {
                                        'location': 
                                        {
                                        'osDependentFilePath': '/home/root/OTA/system_osVersion/stmOs/stmOsDependency/*.zip',
                                        'versionFilePath': '/home/root/OTA/system_osVersion/stmOs/<version>/*.zip',
                                        }, 
                                        'files': 
                                        {
                                        'versionFiles':[<file_names>],
                                        'osFiles': ['Install_1.1.0.zip', 'OS_1.1.0.zip'], 
                                        'stmOsGlbKList': ['1.1.0']
                                        }
                                    }, 
                                    'iomtOs': 
                                    {
                                        'location': 
                                        {
                                        'osDependentFilePath': '/home/root/OTA/system_osVersion/iomtOs/iomtOsDependency/*.zip'
                                        'versionFilePath': '/home/root/OTA/system_osVersion/iomtOs/<version>/*.zip'
                                        }, 
                                        'files': 
                                        {
                                        'versionFiles':[<file_names>],
                                        'osFiles': ['Install_1.1.0.zip', 'OS_1.1.0.zip'], 
                                        'iomtOsGlbKList': ['1.1.0']
                                        }
                                    }
                                    
                                    }, 
                                    
                                    'size': 51696, 
                                    'md5sum': '6f4f69da73c82e4fe8a1a2f48f24e946'
                                    }
                        }  
                     """