# FOTA_STM Application note

Note: Please change the 'host' global variable value(stm.py file) with the IP address of the machine from where Server application is going to run.
      First run the Server.py before running the client (stm.py)

-------------------------------
Command to run the Client:
-------------------------------

python3 stm.py

It will ask for the three input values.

Enter Version Number: current version of the package

Enter Update type: OS/Firmware/Software

Enter update mode(i.e:rollback=0,new=1) : 0/1


-------------------
File Description:
-------------------

stm.py : Main file which will communicate with the Server.

test_logs_fota_stm.txt : Application log file
