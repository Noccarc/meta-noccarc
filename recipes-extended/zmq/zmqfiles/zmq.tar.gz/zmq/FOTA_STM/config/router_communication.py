"""
 FileName      : fota_stm.py

 Description   : This file contains the implementation of FOTA_STM ZMQ dealer. which is reponsible to handle
                 all the incoming message from the Router application. Also sent response to that perticular message
                 with data. Main task of this application is to install the newly received OTA package in to the device 

 Author        : Noccarc
"""
import threading
import zmq
import subprocess 
import json
from json.decoder import JSONDecodeError
import logging
import logging.handlers
import traceback
import sys
from constants.app_macros import *
import time
import socket
import hashlib
import os
import zipfile
import shutil
from distutils.dir_util import copy_tree
import stat
import services.bar_code_scanner as bar_code_scanner
import queue
import utils.RequestQueue as RequestQueue 
from utils.Request import Request
from utils.monitor_log import logger

class RouterCommunication():
    """
    Class        : fota_stm
    Inherits     :
    Description  : Main application class which is handling the ZMQ messages 
    """
    def __init__(self):
        """
        Function: __init__
        Description: init method of class
        @param:
        @return:
        """    
        
        self.running = False
        
        # Intialize the ZMQ dealer instance for the FOTA_STM 
        self.context = zmq.Context.instance()
        self.socket = self.context.socket(zmq.DEALER)
        self.socket.setsockopt(zmq.IDENTITY, bytes(FOTA_STM_DEALER_ID_STR, 'utf-8'))
        # Make connect call with the Router 
        self.socket.connect(ROUTER_SOCKET_ADDRESS)
        self.name = "STM_ROUTER_COMMUNICATION"
        logger.log_info(self.name,"ZMQ connect request sent, dealerID: {0} socketID: {1}".format(FOTA_STM_DEALER_ID, zmq.IDENTITY))
        
    def send_data(self, dJSONMsg):
        """
        Function: send_data
        Description: Send the JSON message to router application
        @param dJSONMsg: JSON dictonary to be sent to Router application
        @return: 
        """
        try:
            logger.log_info(self.name,">>>  {}".format(dJSONMsg))
            #Convert JSON message dictonary to string
            json_obj_to_send = json.dumps(dJSONMsg)
            self.socket.send_multipart([b'1', bytes(json_obj_to_send,'utf-8')])
            logger.log_info(self.name,"JSON message sent to the Router")
        except Exception as e:
            logger.log_error(self.name,"Failed to send JSON message: {0} error: {1}".format(dJSONMsg,e))
            logger.log_error(self.name,traceback.format_exc())
            
    def socket_recieve(self):        
        while self.running:   
                   
            # Blocking zmq received call 
            self.socket.recv()
            received_data = self.socket.recv()
            try:
                received_data = json.loads(received_data)
            except JSONDecodeError as e:
                logger.log_error(self.name,"JSON parsing failed: {0}".format(e))
                continue
            logger.log_info(self.name,"<<<  {}".format(received_data))
            # send request
            req = Request()
            req.url = "router/request"
            req.data = received_data
            RequestQueue.setRequest(req)
            
    def run(self):
        if not self.running:
            self.running = True
            
            th_object = threading.Thread(target=self.socket_recieve)
            th_object.start()
            
            dJSONMsg = {}
            dJSONMsg[SOURCE_KEY] = FOTA_STM_DEALER_ID
            dJSONMsg[DESTINATION_KEY] = ROUTER_ID
            dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_REG
            dJSONMsg[DATA_KEY] = {}
            self.send_data(dJSONMsg)


RouterComObj = RouterCommunication()

