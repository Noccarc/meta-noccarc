
import threading

# A shared resource that can be accessed by multiple threads
shared_resource = []

# A condition object that will be used for conditional waiting
condition = threading.Condition()

# A function that adds an item to the shared resource
def setRequest(req):
    global shared_resource
    with condition:
        shared_resource.append(req)
        # Notify any waiting threads that a new item has been added
        condition.notify()

# A function that removes an item from the shared resource
def getRequest():
    global shared_resource
    with condition:
        # Wait until the shared resource is not empty
        while not shared_resource:
            condition.wait()
        # Remove the first item from the shared resource
        req = shared_resource.pop(0)
        return req

