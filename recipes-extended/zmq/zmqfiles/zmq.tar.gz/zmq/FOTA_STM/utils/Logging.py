import logging
import logging.handlers
import traceback
import sys
from constants.app_macros import *
                            
""" 
Function: logging_setup
Description: This function setup the logging for the Application. This function takes the 
values from the logging_types dictonary. based on that it will decide where applicaiton logs 
should be print on colsole and logging file
"""

ERROR_LOG_FILE_NAME = "error_log.txt"

# Define the SUCCESS log level
# Define the SUCCESS log level
logging.SUCCESS = 25  # You can choose any integer value that is not used by other levels
logging.addLevelName(logging.SUCCESS, "SUCCESS")
class CustomFormatter(logging.Formatter):

    blue = '\x1b[38;5;39m'
    yellow = "\x1b[33;20m"
    red = "\x1b[31;20m"
    green = "\x1b[32;20m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"
    format = "%(asctime)s - %(levelname)s - %(message)s  (%(filename)s:%(lineno)d)"

    FORMATS = {
        logging.DEBUG: yellow + format + reset,
        logging.INFO: blue + format + reset,
        logging.WARNING: yellow + format + reset,
        logging.ERROR: red + format + reset,
        logging.CRITICAL: bold_red + format + reset,
        logging.SUCCESS: green + format + reset 
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)

def logging_setup():
    
    root = logging.getLogger()
    root.setLevel(logging.INFO)

    # Print the logs in to the console, if "log_into_console" key is true
    if logging_types['log_into_console'] == True:
        ch = logging.StreamHandler(sys.stdout)
        # TODO: Here developer can decide the log level which will be print over the console
        ch.setLevel(logging.INFO)
        # formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        ch.setFormatter(CustomFormatter())
        root.addHandler(ch)

    # Store the logs in to the file if "log_into_file" key is true
    if logging_types['log_into_file'] == True:
        log_file_handler = logging.handlers.RotatingFileHandler(LOG_FILE_NAME, 
                                                                maxBytes = LOG_FILE_SIZE, 
                                                                backupCount = LOG_FILE_BACK_COUNT)
        # TODO: Here developer can decide the log level which will stored in to the log file
        log_file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        log_file_handler.setFormatter(formatter)
        root.addHandler(log_file_handler)

        # Error Logs will be stored "errorLogs.txt"
        # error_log_file_handle
        error_log_file_handler = logging.FileHandler(ERROR_LOG_FILE_NAME)
        error_log_file_handler.setLevel(logging.ERROR)
        error_log_file_handler.setFormatter(CustomFormatter())
        root.addHandler(error_log_file_handler)
    return root


logger = logging_setup()
