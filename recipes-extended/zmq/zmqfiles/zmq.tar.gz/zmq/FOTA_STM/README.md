# FOTA_STM 

## changes

[test-release]
- old [stm_py_updateStatus = True] --> changed to False
- refactored the logging code.
- Firmware Update bug fixed .
- Fixed logger error in Barcode scanner.
- fixed slave copy error


[5/01/24]
- in main.py : work() now logger will first clear then request logs then parse request

[10/01/24]
- version : 1.1.0 , Date : 10/01/24
- Description : 
    - Implemented Updating STM OS , UI and Backend , Firmware. 
    - Implemented rollback for UI and Backend.

[17/01/24]
- version : 1.1.0 , Date : 17/01/24
- Description :
    - release version : 1.1.0 
    - It contains : update UI and Backend , update Firmware , Update stmOS. 