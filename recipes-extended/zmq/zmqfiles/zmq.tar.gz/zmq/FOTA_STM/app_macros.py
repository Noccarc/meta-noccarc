FOTA_IOMT_DEALER_ID = 4
FOTA_STM_DEALER_ID = 3
FOTA_STM_DEALER_ID_STR = '3'
BACKEND_DEALER_ID = 2
ROUTER_ID = 1
SOURCE_KEY='source'
DESTINATION_KEY='destination'
MESSAGE_TYPE_KEY='type'
DATA_KEY='data'
STATUS_KEY = 'status'
PKG_TYPE_KEY = 'pkg_type'
PKG_VERSION_KEY = 'version'
PKG_NAME_KEY = "name"
PKG_SIZE_KEY = "size"
PKG_MD5SUM_KEY = "md5sum"
PKG_LOCATION_KEY = "location"
STATUS_KEY = "status"


ROUTER_SOCKET_ADDRESS = "tcp://localhost:5555"
IOMT_IP_ADDRESS = "192.168.0.2"
FIRMWARE_PATH_IN_DEVICE = "/usr/local/VCB-OTA/OTA/Firmware"
SOFTWARE_BACKEND_PATH_IN_DEVICE = "/usr/local/HMIfiles/apps/Noccarc_Backend"
SOFTWARE_UI_PATH_IN_DEVICE = "/usr/local/HMIfiles/apps/"

ota_pkg_files_locaiton = {   \
"Master" : "Firmware/Master.hex", \
"Slave" : "Firmware/Slave.hex", \
"backend" : "Software/backend.bin", \
"UI" : "Software/Noccarc_UI"
}

BACKEND_BINARY_NAME = "backend.bin"

# ota_pkg_files_locaiton = {   \
# "Master" : "Firmware/Master.hex", \
# "Slave" : "Firmware/Slave.hex", \
# "backend" : "Software/V730i_1.1.1.17.bin", \
# "UI" : "Software/Noccarc_UI_1.1.1.18"
# }

dFlashErrorList = { \
1 : "Error: error executing stm32x flash write algorithm",              # Received ERROR when flash write failed
2 : "Error: JTAG-DP STICKY ERROR",                                      # Received ERROR when JTAG cable is not connected
3 : "Error: checksum mismatch - attempting binary compare"              # Received ERROR when checksum mismatch
} 

MSG_TYPE_REG = 1
MSG_TYPE_HEART_BEAT = 2
MSG_TYPE_NEW_UPDATE_CHECK = 5
MSG_TYPE_PKG_UPGRADE = 6
MSG_TYPE_PKG_DOWNLOADED = 7
MSG_TYPE_PKG_ROLLBACK  = 8
MSG_TYPE_CONNECTED_WIFI_NAME = 13
MSG_TYPE_ROLLBACK_FEEDBACK = 15

LOG_FILE_NAME = "fota_stm_logging.txt"
LOG_FILE_SIZE = 1024 * 1024 * 2
LOG_FILE_BACK_COUNT = 3
DELAY_BETWEEN_TWO_FIRMWARE_FLASH = 5

SUCCESS = 1
ERROR_CODE_ROLLBACK_PKG_NOT_AVAILABLE = -3
ERROR_CODE_PKG_DOWNLOAD_FAILED = -5
ERROR_CODE_FAILED_TO_GET_NEW_UPDATE = -4
ERROR_CODE_PKG_NO_UPDATE_AVAILABLE = -6
ERROR_CODE_INVALID_JSON = -7
ERROR_CODE_WIFI_CONNECTED_NO_INTERNET = -8
ERROR_CODE_FAILED_TO_FETCH_WIFI_LIST = -9
ERROR_CODE_WIFI_CONNECT_FAILED = -10
ERROR_CODE_WIFI_NOT_CONNECTED_TO_STATION = -11
ERROR_CODE_FAILED_TO_OFF_WIFI = -12
ERROR_CODE_NO_PACKAGE_AVAILABLE = -13
ERROR_CODE_FAILED_TO_INSTALL_PKG = -15
ERROR_CODE_PACKAGE_VERIFICATION_FAILED = -16
ERROR_CODE_INVALID_PACKAGE_INFO_JSON = -17

PACKAGE_TYPE_UPGRADE = 1
PACKAGE_TYPE_ROLLBACK = 2

logging_types = {"log_into_console":True, "log_into_file" : True} 
